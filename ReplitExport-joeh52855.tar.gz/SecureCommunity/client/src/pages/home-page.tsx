import { ServerSidebar } from "@/components/server-sidebar";
import { ChannelSidebar } from "@/components/channel-sidebar";
import { ChatArea } from "@/components/chat-area";
import { SettingsBar } from "@/components/settings-bar";
import { useQuery } from "@tanstack/react-query";
import { Server } from "@shared/schema";
import { useState } from "react";

export default function HomePage() {
  const [selectedServer, setSelectedServer] = useState<Server | null>(null);
  const [selectedChannelId, setSelectedChannelId] = useState<number | null>(null);

  const { data: servers = [] } = useQuery<Server[]>({
    queryKey: ["/api/me/servers"],  
  });

  return (
    <div className="flex h-screen bg-background">
      <ServerSidebar
        servers={servers}
        selectedServer={selectedServer}
        onServerSelect={setSelectedServer}
      />

      {selectedServer && (
        <ChannelSidebar
          server={selectedServer}
          selectedChannelId={selectedChannelId}
          onChannelSelect={setSelectedChannelId}
        />
      )}

      {selectedChannelId && (
        <ChatArea channelId={selectedChannelId} />
      )}

      {!selectedServer && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          Select a server to get started
        </div>
      )}

      {selectedServer && !selectedChannelId && (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          Select a channel to start chatting
        </div>
      )}

      <SettingsBar />
    </div>
  );
}