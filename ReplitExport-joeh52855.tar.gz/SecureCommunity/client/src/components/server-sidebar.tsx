import { Server } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

type ServerSidebarProps = {
  servers: Server[];
  selectedServer: Server | null;
  onServerSelect: (server: Server) => void;
};

export function ServerSidebar({ servers, selectedServer, onServerSelect }: ServerSidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [serverName, setServerName] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();

  const createServerMutation = useMutation({
    mutationFn: async (name: string) => {
      if (!user) throw new Error("You must be logged in to create a server");
      const res = await apiRequest("POST", "/api/servers", { 
        name,
        ownerId: user.id 
      });
      return res.json();
    },
    onSuccess: (newServer: Server) => {
      queryClient.invalidateQueries({ queryKey: ["/api/me/servers"] });
      setIsOpen(false);
      setServerName("");
      onServerSelect(newServer);
      toast({
        title: "Server created",
        description: `${newServer.name} has been created successfully`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create server",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="w-[72px] h-full bg-sidebar flex flex-col items-center py-3 gap-2">
      {servers.map((server) => (
        <button
          key={server.id}
          onClick={() => onServerSelect(server)}
          className={cn(
            "w-12 h-12 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors",
            "flex items-center justify-center font-semibold text-lg",
            selectedServer?.id === server.id && "bg-primary/30"
          )}
        >
          {server.name[0].toUpperCase()}
        </button>
      ))}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full w-12 h-12 mt-2"
          >
            <Plus className="h-6 w-6" />
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create a new server</DialogTitle>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (serverName.trim()) {
                createServerMutation.mutate(serverName);
              }
            }}
            className="space-y-4"
          >
            <Input
              placeholder="Server name"
              value={serverName}
              onChange={(e) => setServerName(e.target.value)}
            />
            <Button
              type="submit"
              className="w-full"
              disabled={!serverName.trim() || createServerMutation.isPending}
            >
              Create Server
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}