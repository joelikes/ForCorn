
import * as React from "react";
import { Message } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { format } from "date-fns";

type ChatAreaProps = {
  channelId?: number;
  userId?: number;
};

export function ChatArea({ channelId, userId }: ChatAreaProps) {
  const queryEndpoint = userId 
    ? `/api/direct-messages/${userId}`
    : `/api/channels/${channelId}/messages`;
  const [message, setMessage] = React.useState("");
  const { user } = useAuth();
  const scrollRef = React.useRef<HTMLDivElement>(null);
  
  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: [queryEndpoint],
    enabled: Boolean(channelId || userId),
    refetchInterval: 1000,
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    retry: 3
  });

  React.useEffect(() => {
    const scrollElement = scrollRef.current;
    if (scrollElement) {
      scrollElement.scrollTop = scrollElement.scrollHeight;
    }
  }, [messages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const endpoint = userId 
        ? `/api/direct-messages/${userId}`
        : `/api/channels/${channelId}/messages`;
      const res = await apiRequest("POST", endpoint, {
        content,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: [queryEndpoint],
        exact: true
      });
      queryClient.refetchQueries({
        queryKey: [queryEndpoint],
        exact: true
      });
    },
  });

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if ((e.key === 'Enter' || e.code === 'Enter') && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSendMessage = () => {
    if (message.trim() && !sendMessageMutation.isPending) {
      const content = message.trim();
      setMessage("");
      sendMessageMutation.mutate(content);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#313338]">
      <div className="border-b border-[#2B2D31] px-4 py-3">
        <h2 className="font-semibold text-[#F2F3F5]">Chat</h2>
      </div>

      <div className="flex-1 overflow-y-auto" ref={scrollRef}>
        <div className="min-h-full p-4 space-y-2">
          {messages.map((message, index) => {
            const isFirstMessage = index === 0;
            const prevMessage = !isFirstMessage ? messages[index - 1] : null;
            const showHeader = isFirstMessage || 
              prevMessage?.userId !== message.userId ||
              new Date(message.createdAt).getTime() - new Date(prevMessage?.createdAt || 0).getTime() > 300000;

            return (
              <div 
                key={message.id}
                className="group hover:bg-[#2E3035] -mx-4 px-4 py-[2px] transition-colors"
              >
                {showHeader && (
                  <div className="flex items-start gap-x-2 mt-4 mb-0.5">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-[#5865F2] text-white">
                        {String(message.userId)[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-baseline gap-x-2">
                        <span className="font-medium text-[#F2F3F5] hover:underline cursor-pointer">
                          User {message.userId}
                        </span>
                        <span className="text-xs text-[#949BA4]">
                          {format(new Date(message.createdAt), "MM/dd/yyyy h:mm a")}
                        </span>
                      </div>
                      <p className="text-[#DBDEE1] leading-[1.375rem] mt-0.5">{message.content}</p>
                    </div>
                  </div>
                )}
                {!showHeader && (
                  <p className="text-[#DBDEE1] leading-[1.375rem] pl-12">{message.content}</p>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="px-4 py-4 mt-auto">
        <form onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage();
        }} className="relative bg-[#383A40] rounded-lg">
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder={userId ? "Send a message..." : "Message #general"}
            className="min-h-[44px] max-h-[300px] resize-none bg-transparent border-none text-[#DBDEE1] placeholder:text-[#949BA4] focus-visible:ring-0 focus-visible:ring-offset-0 pr-12"
            rows={1}
          />
          <Button
            size="icon"
            variant="ghost"
            className="absolute right-2 bottom-2 h-6 w-6 hover:bg-[#4E5058] text-[#B5BAC1] opacity-75 hover:opacity-100 transition-opacity"
            onClick={handleSendMessage}
            disabled={!message.trim() || sendMessageMutation.isPending || !channelId}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </div>
    </div>
  );
}
