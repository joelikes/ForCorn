
import { User } from "@shared/schema";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageSquare } from "lucide-react";
import { useState } from "react";
import { ChatArea } from "./chat-area";

interface ProfileModalProps {
  user: User | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
}

export function ProfileModal({ user, isOpen, onClose, currentUser }: ProfileModalProps) {
  const [showChat, setShowChat] = useState(false);

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={() => onClose()}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Profile</DialogTitle>
        </DialogHeader>
        
        <div className="flex flex-col items-center gap-4 py-4">
          <Avatar className="h-20 w-20">
            <AvatarFallback className="text-xl">
              {user.username[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="text-center">
            <h2 className="text-xl font-semibold">{user.username}</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {user.status || "offline"}
            </p>
          </div>

          {user.bio && (
            <div className="w-full">
              <h3 className="text-sm font-medium mb-2">About</h3>
              <p className="text-sm text-muted-foreground">{user.bio}</p>
            </div>
          )}

          {currentUser && currentUser.id !== user.id && (
            <Button 
              className="w-full mt-4"
              onClick={() => setShowChat(true)}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Send Message
            </Button>
          )}
        </div>

        {showChat && (
          <div className="mt-4 border-t pt-4">
            <h3 className="text-sm font-medium mb-2">Messages</h3>
            <div className="h-[400px] border rounded-md overflow-hidden">
              <ChatArea userId={user.id} />
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
