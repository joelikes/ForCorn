import { Server, Channel } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { HashIcon, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type ChannelSidebarProps = {
  server: Server;
  selectedChannelId: number | null;
  onChannelSelect: (channelId: number) => void;
};

export function ChannelSidebar({
  server,
  selectedChannelId,
  onChannelSelect,
}: ChannelSidebarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [channelName, setChannelName] = useState("");
  const { toast } = useToast();

  const { data: channels = [] } = useQuery<Channel[]>({
    queryKey: [`/api/servers/${server.id}/channels`],
  });

  const createChannelMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("POST", `/api/servers/${server.id}/channels`, {
        name,
      });
      return res.json();
    },
    onSuccess: (newChannel: Channel) => {
      queryClient.invalidateQueries({
        queryKey: [`/api/servers/${server.id}/channels`],
      });
      setIsOpen(false);
      setChannelName("");
      toast({
        title: "Channel created",
        description: `#${newChannel.name} has been created successfully`,
      });
    },
  });

  return (
    <div className="w-60 h-full bg-sidebar border-r border-sidebar-border flex flex-col">
      <div className="p-4 border-b border-sidebar-border">
        <h2 className="font-semibold text-lg text-sidebar-foreground">
          {server.name}
        </h2>
      </div>

      <div className="flex-1 p-3 space-y-2">
        <div className="flex items-center justify-between px-2">
          <span className="text-xs font-semibold text-sidebar-foreground/60 uppercase">
            Channels
          </span>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="icon" className="h-4 w-4">
                <Plus className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create a new channel</DialogTitle>
              </DialogHeader>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  createChannelMutation.mutate(channelName);
                }}
                className="space-y-4"
              >
                <Input
                  placeholder="Channel name"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                />
                <Button
                  type="submit"
                  className="w-full"
                  disabled={!channelName || createChannelMutation.isPending}
                >
                  Create Channel
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {channels.map((channel) => (
          <button
            key={channel.id}
            onClick={() => onChannelSelect(channel.id)}
            className={cn(
              "w-full px-2 py-1 rounded flex items-center gap-2 hover:bg-sidebar-accent/50 transition-colors",
              selectedChannelId === channel.id && "bg-sidebar-accent"
            )}
          >
            <HashIcon className="h-4 w-4 text-sidebar-foreground/60" />
            <span className="text-sidebar-foreground text-sm">{channel.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
