import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Bell, LogOut, Users, Search, UserPlus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import type { FriendRequest, User } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ProfileModal } from "./profile-modal";

export function SettingsBar() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [showFriendRequests, setShowFriendRequests] = useState(false);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [searchUsername, setSearchUsername] = useState("");
  const [selectedProfile, setSelectedProfile] = useState<User | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  const { data: friendRequests = [] } = useQuery<FriendRequest[]>({
    queryKey: ["/api/friend-requests"],
  });

  const { data: friends = [] } = useQuery<User[]>({
    queryKey: ["/api/friends"],
  });

  const acceptFriendRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      await apiRequest("POST", `/api/friend-requests/${requestId}/accept`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      toast({
        title: "Friend request accepted",
        description: "You are now friends!",
      });
    },
  });

  const sendFriendRequestMutation = useMutation({
    mutationFn: async (userId: number) => {
      await apiRequest("POST", `/api/friend-requests/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Friend request sent",
        description: "Friend request sent successfully!",
      });
      setSearchUsername("");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send friend request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const { data: searchResults = [] } = useQuery<User[]>({
    queryKey: ["/api/users/search", searchUsername],
    enabled: searchUsername.length > 0,
  });

  return (
    <div className="w-60 h-full bg-sidebar border-l border-sidebar-border flex flex-col">
      {/* User Profile Section */}
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarFallback>
              {user?.username[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{user?.username}</p>
            <p className="text-xs text-muted-foreground">Online</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex-1 p-4 space-y-2">
        <Button
          variant="ghost"
          className="w-full justify-start"
          onClick={() => {
            setShowFriendRequests(false);
            setShowAddFriend(false);
          }}
        >
          <Users className="h-4 w-4 mr-2" />
          Friends ({friends.length})
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start"
          onClick={() => {
            setShowFriendRequests(true);
            setShowAddFriend(false);
          }}
        >
          <Bell className="h-4 w-4 mr-2" />
          Friend Requests ({friendRequests.length})
        </Button>
        <Button
          variant="ghost"
          className="w-full justify-start"
          onClick={() => {
            setShowAddFriend(true);
            setShowFriendRequests(false);
          }}
        >
          <UserPlus className="h-4 w-4 mr-2" />
          Add Friend
        </Button>
      </div>

      {/* Content Area */}
      <div className="flex-1 p-4 overflow-y-auto">
        {showAddFriend && (
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                className="pl-9"
                placeholder="Search username..."
                value={searchUsername}
                onChange={(e) => setSearchUsername(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              {searchResults.map((result) => (
                <Card key={result.id} className="p-3">
                  <div className="flex items-center gap-2">
                    <Avatar>
                      <AvatarFallback>
                        {result.username[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{result.username}</p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => sendFriendRequestMutation.mutate(result.id)}
                      disabled={sendFriendRequestMutation.isPending}
                    >
                      Add Friend
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {showFriendRequests && (
          <div className="space-y-2">
            {friendRequests.map((request) => (
              <Card key={request.id} className="p-3">
                <div className="flex items-center gap-2">
                  <Avatar>
                    <AvatarFallback>
                      {request.senderId.toString()[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">User {request.senderId}</p>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => acceptFriendRequestMutation.mutate(request.id)}
                    disabled={acceptFriendRequestMutation.isPending}
                  >
                    Accept
                  </Button>
                </div>
              </Card>
            ))}
            {friendRequests.length === 0 && (
              <p className="text-sm text-muted-foreground text-center">
                No pending friend requests
              </p>
            )}
          </div>
        )}

        {!showFriendRequests && !showAddFriend && (
          <div className="space-y-2">
            {friends.map((friend) => (
              <Card
                key={friend.id}
                className="p-3 cursor-pointer hover:bg-accent/50 transition-colors"
                onClick={() => {
                  setSelectedProfile(friend);
                  setIsProfileModalOpen(true);
                }}
              >
                <div className="flex items-center gap-2">
                  <Avatar>
                    <AvatarFallback>
                      {friend.username[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <p className="text-sm font-medium">{friend.username}</p>
                </div>
              </Card>
            ))}
            {friends.length === 0 && (
              <p className="text-sm text-muted-foreground text-center">
                No friends yet
              </p>
            )}
          </div>
        )}
      </div>

      {/* Settings Footer */}
      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className="w-full justify-start text-destructive"
          onClick={() => logoutMutation.mutate()}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>
      </div>
      <ProfileModal
        user={selectedProfile}
        isOpen={isProfileModalOpen}
        onClose={() => {
          setIsProfileModalOpen(false);
          setSelectedProfile(null);
        }}
        currentUser={user}
      />
    </div>
  );
}