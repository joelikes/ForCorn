import { users, servers, channels, messages, friendRequests, friends, serverMembers } from "@shared/schema";
import { eq, and, or, not, like } from "drizzle-orm";
import { db, pool } from "./db";
import session from "express-session";
import connectPg from "connect-pg-simple";
import type { User, InsertUser, Server, Channel, Message, FriendRequest, Friend, ServerMember } from "@shared/schema";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  sessionStore: session.Store;

  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Server operations
  createServer(name: string, ownerId: number): Promise<Server>;
  getServers(): Promise<Server[]>;
  getServerById(id: number): Promise<Server | undefined>;
  joinServer(userId: number, serverId: number): Promise<ServerMember>;
  leaveServer(userId: number, serverId: number): Promise<void>;
  getServerMembers(serverId: number): Promise<User[]>;
  getUserServers(userId: number): Promise<Server[]>;

  // Channel operations
  createChannel(name: string, serverId: number): Promise<Channel>;
  getChannelsByServer(serverId: number): Promise<Channel[]>;

  // Message operations
  createMessage(content: string, channelId: number, userId: number): Promise<Message>;
  getMessagesByChannel(channelId: number): Promise<Message[]>;

  // Friend operations
  sendFriendRequest(senderId: number, receiverId: number): Promise<FriendRequest>;
  getFriendRequests(userId: number): Promise<FriendRequest[]>;
  acceptFriendRequest(requestId: number): Promise<Friend>;
  rejectFriendRequest(requestId: number): Promise<void>;
  getFriends(userId: number): Promise<User[]>;

  // Search operation
  searchUsers(username: string, currentUserId: number): Promise<User[]>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async createServer(name: string, ownerId: number): Promise<Server> {
    const [server] = await db
      .insert(servers)
      .values({ name, ownerId })
      .returning();
    return server;
  }

  async getServers(): Promise<Server[]> {
    return await db.select().from(servers);
  }

  async getServerById(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }

  async joinServer(userId: number, serverId: number): Promise<ServerMember> {
    const [member] = await db
      .insert(serverMembers)
      .values({ userId, serverId })
      .returning();
    return member;
  }

  async leaveServer(userId: number, serverId: number): Promise<void> {
    await db
      .delete(serverMembers)
      .where(and(
        eq(serverMembers.userId, userId),
        eq(serverMembers.serverId, serverId)
      ));
  }

  async getServerMembers(serverId: number): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .innerJoin(serverMembers, eq(users.id, serverMembers.userId))
      .where(eq(serverMembers.serverId, serverId))
      .then(rows => rows.map(row => row.users));
  }

  async getUserServers(userId: number): Promise<Server[]> {
    return await db
      .select()
      .from(servers)
      .innerJoin(serverMembers, eq(servers.id, serverMembers.serverId))
      .where(eq(serverMembers.userId, userId))
      .then(rows => rows.map(row => row.servers));
  }

  async createChannel(name: string, serverId: number): Promise<Channel> {
    const [channel] = await db
      .insert(channels)
      .values({ name, serverId })
      .returning();
    return channel;
  }

  async getChannelsByServer(serverId: number): Promise<Channel[]> {
    return await db
      .select()
      .from(channels)
      .where(eq(channels.serverId, serverId));
  }

  async createMessage(
    content: string,
    channelId: number,
    userId: number
  ): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values({ content, channelId, userId })
      .returning();
    return message;
  }

  async getMessagesByChannel(channelId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.channelId, channelId))
      .orderBy(messages.createdAt);
  }

  async sendFriendRequest(senderId: number, receiverId: number): Promise<FriendRequest> {
    const [request] = await db
      .insert(friendRequests)
      .values({ senderId, receiverId })
      .returning();
    return request;
  }

  async getFriendRequests(userId: number): Promise<FriendRequest[]> {
    return await db
      .select()
      .from(friendRequests)
      .where(
        and(
          eq(friendRequests.receiverId, userId),
          eq(friendRequests.status, "pending")
        )
      );
  }

  async acceptFriendRequest(requestId: number): Promise<Friend> {
    const [request] = await db
      .update(friendRequests)
      .set({ status: "accepted" })
      .where(eq(friendRequests.id, requestId))
      .returning();

    const [friendship] = await db
      .insert(friends)
      .values({
        user1Id: request.senderId,
        user2Id: request.receiverId,
      })
      .returning();

    return friendship;
  }

  async rejectFriendRequest(requestId: number): Promise<void> {
    await db
      .update(friendRequests)
      .set({ status: "rejected" })
      .where(eq(friendRequests.id, requestId));
  }

  async getFriends(userId: number): Promise<User[]> {
    const friendships = await db
      .select()
      .from(friends)
      .where(or(
        eq(friends.user1Id, userId),
        eq(friends.user2Id, userId)
      ));

    const friendIds = friendships.map(f =>
      f.user1Id === userId ? f.user2Id : f.user1Id
    );

    return await db
      .select()
      .from(users)
      .where(
        and(
          not(eq(users.id, userId)),
          or(...friendIds.map(id => eq(users.id, id)))
        )
      );
  }

  async searchUsers(username: string, currentUserId: number): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(
        and(
          not(eq(users.id, currentUserId)),
          like(users.username, `%${username}%`)
        )
      )
      .limit(10);
  }
}

export const storage = new DatabaseStorage();