import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertServerSchema, insertChannelSchema, insertMessageSchema } from "@shared/schema";
import rateLimit from "express-rate-limit";

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.use("/api", apiLimiter);

  // Friend request routes
  app.post("/api/friend-requests/:userId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const receiverId = parseInt(req.params.userId);
    if (receiverId === req.user!.id) return res.status(400).send("Cannot send friend request to yourself");

    const request = await storage.sendFriendRequest(req.user!.id, receiverId);
    res.status(201).json(request);
  });

  app.get("/api/friend-requests", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const requests = await storage.getFriendRequests(req.user!.id);
    res.json(requests);
  });

  app.post("/api/friend-requests/:requestId/accept", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const friendship = await storage.acceptFriendRequest(parseInt(req.params.requestId));
    res.status(201).json(friendship);
  });

  app.post("/api/friend-requests/:requestId/reject", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    await storage.rejectFriendRequest(parseInt(req.params.requestId));
    res.sendStatus(200);
  });

  app.get("/api/friends", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const friends = await storage.getFriends(req.user!.id);
    res.json(friends);
  });

  // Add this new route after the other friend-related routes
  app.get("/api/users/search", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const username = req.query.username as string;
    if (!username) return res.json([]);

    const users = await storage.searchUsers(username, req.user!.id);
    res.json(users);
  });

  // Server membership routes
  app.post("/api/servers/:serverId/join", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const member = await storage.joinServer(req.user!.id, parseInt(req.params.serverId));
    res.status(201).json(member);
  });

  app.post("/api/servers/:serverId/leave", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    await storage.leaveServer(req.user!.id, parseInt(req.params.serverId));
    res.sendStatus(200);
  });

  app.get("/api/servers/:serverId/members", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const members = await storage.getServerMembers(parseInt(req.params.serverId));
    res.json(members);
  });

  app.get("/api/me/servers", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const servers = await storage.getUserServers(req.user!.id);
    res.json(servers);
  });

  // Existing server routes
  app.post("/api/servers", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const result = insertServerSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json(result.error);

    const server = await storage.createServer(result.data.name, req.user!.id);
    // Automatically add the creator as a member
    await storage.joinServer(req.user!.id, server.id);
    res.status(201).json(server);
  });

  // Channel routes
  app.post("/api/servers/:serverId/channels", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const result = insertChannelSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json(result.error);

    const server = await storage.getServerById(parseInt(req.params.serverId));
    if (!server) return res.sendStatus(404);
    if (server.ownerId !== req.user!.id) return res.sendStatus(403);

    const channel = await storage.createChannel(result.data.name, server.id);
    res.status(201).json(channel);
  });

  app.get("/api/servers/:serverId/channels", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const channels = await storage.getChannelsByServer(parseInt(req.params.serverId));
    res.json(channels);
  });

  // Message routes
  app.post("/api/channels/:channelId/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    const result = insertMessageSchema.safeParse(req.body);
    if (!result.success) return res.status(400).json(result.error);

    const message = await storage.createMessage(
      result.data.content,
      parseInt(req.params.channelId),
      req.user!.id
    );
    res.status(201).json(message);
  });

  app.get("/api/channels/:channelId/messages", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const channelId = parseInt(req.params.channelId);
    if (isNaN(channelId)) {
      return res.status(400).json({ error: "Invalid channel ID" });
    }

    const messages = await storage.getMessagesByChannel(channelId);
    res.json(messages);
  });

  app.get("/api/servers", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const servers = await storage.getServers();
    res.json(servers);
  });


  const httpServer = createServer(app);
  return httpServer;
}