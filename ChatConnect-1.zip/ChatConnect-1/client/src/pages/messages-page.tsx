import { DirectMessageList } from "@/components/layout/direct-message-list";
import { ServerSidebar } from "@/components/layout/server-sidebar";
import { useQuery } from "@tanstack/react-query";
import type { Server } from "@shared/schema";
import { MessageArea } from "@/components/layout/message-area";
import { useEffect } from "react";
import { useSelectedChannel } from "@/hooks/use-selected-channel";

export default function MessagesPage() {
  const { setSelectedChannel } = useSelectedChannel();
  const { data: servers = [] } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });

  // Clear any selected channel when entering messages page
  useEffect(() => {
    setSelectedChannel(null);
  }, []);

  const params = new URLSearchParams(window.location.search);
  const selectedUserId = params.get('userId');

  return (
    <div className="flex h-screen overflow-hidden">
      <ServerSidebar />
      <DirectMessageList />
      {selectedUserId ? (
        <div className="flex-1 h-full overflow-hidden">
          <MessageArea />
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-muted-foreground">
          Select a conversation to start messaging
        </div>
      )}
    </div>
  );
}