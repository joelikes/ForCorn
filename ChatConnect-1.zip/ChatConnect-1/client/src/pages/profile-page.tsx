import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { User } from "@shared/schema";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const userId = parseInt(id);

  const { data: user, isLoading } = useQuery<User>({
    queryKey: ["/api/users", userId],
    enabled: !isNaN(userId),
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold">User not found</h2>
          <p className="text-muted-foreground">This user profile doesn't exist.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-2xl mx-auto py-8 px-4">
      <Card className="p-6">
        <div className="flex items-start gap-6">
          <Avatar className="h-24 w-24">
            <AvatarImage
              src={user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length]}
              alt={user.username}
            />
          </Avatar>
          <div className="flex-1">
            <h1 className="text-2xl font-bold">
              {user.displayName || user.username}
            </h1>
            <p className="text-muted-foreground">@{user.username}</p>
            {user.aboutMe && (
              <p className="mt-4 text-sm">{user.aboutMe}</p>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
