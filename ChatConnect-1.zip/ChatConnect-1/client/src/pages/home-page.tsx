import { ServerSidebar } from "@/components/layout/server-sidebar";
import { ChannelList } from "@/components/layout/channel-list";
import { MessageArea } from "@/components/layout/message-area";
import { FriendRequestSection } from "@/components/layout/friend-request-section";
import { useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import type { Server } from "@shared/schema";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { DirectMessageList } from "@/components/layout/direct-message-list";

export default function HomePage() {
  const { selectedServerId } = useSelectedChannel();
  const { data: servers, isLoading } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      <ServerSidebar servers={servers || []} />
      <div className="flex flex-1 min-w-0">
        {/* Left sidebar: Show ChannelList for servers, DirectMessageList for DMs */}
        <div className="w-80 bg-muted border-r flex flex-col">
          {selectedServerId ? (
            <ChannelList />
          ) : (
            <DirectMessageList />
          )}
        </div>

        {/* Main content area */}
        <div className="flex-1 flex min-w-0 max-w-[calc(100%-20rem)]">
          <MessageArea />
        </div>

        {/* Right sidebar - Only show for DMs */}
        {!selectedServerId && (
          <div className="w-96 bg-muted border-l flex flex-col">
            <FriendRequestSection />
          </div>
        )}
      </div>
    </div>
  );
}