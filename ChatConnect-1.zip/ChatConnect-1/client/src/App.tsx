import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import MessagesPage from "@/pages/messages-page";
import { ProtectedRoute } from "./lib/protected-route";
import { useState } from "react";
import { JoinServerDialog } from "./components/dialogs/join-server-dialog";
import { useLocation } from "wouter";
import { useWebSocket } from "@/hooks/use-websocket";
import { NotificationListener } from "@/components/notification-toast";
import { ChannelProvider } from "@/components/context/channel-context";
import { Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProfileSettingsDialog } from "./components/dialogs/profile-settings-dialog";
import { useAuth } from "@/hooks/use-auth";
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarProvider
} from "@/components/ui/sidebar";

function InvitePage({ params: { code } }: { params: { code: string } }) {
  const [, setLocation] = useLocation();
  const [showDialog, setShowDialog] = useState(true);

  return (
    <>
      <JoinServerDialog
        inviteCode={code}
        isOpen={showDialog}
        onClose={() => {
          setShowDialog(false);
          setLocation('/');
        }}
      />
      <MessagesPage />
    </>
  );
}

function Router() {
  useWebSocket();
  const [showProfileSettings, setShowProfileSettings] = useState(false);
  const { user } = useAuth();

  if (location.pathname === '/auth') {
    return <AuthPage />;
  }

  return (
    <div className="h-screen w-screen flex bg-background p-0 m-0 overflow-hidden">
      <SidebarProvider defaultOpen={true}>
        <div className="flex-shrink-0 border-r bg-muted/10 p-0">
          <Sidebar className="p-0 m-0">
            <SidebarHeader className="p-1 border-b flex items-center justify-between">
              <div className="flex items-center gap-1">
                <img src="/logo.webp" alt="Logo" className="w-4 h-4" />
                <span className="font-semibold text-xs">ForCorn</span>
              </div>
            </SidebarHeader>
            <SidebarContent className="p-0" />
          </Sidebar>
        </div>

        <div className="flex-1 flex flex-col min-w-0 p-0">
          <header className="h-10 border-b flex items-center justify-between px-2 bg-background">
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold">Home</h1>
            </div>
            {user && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowProfileSettings(true)}
                className="h-6 w-6"
              >
                <Settings className="h-3 w-3" />
              </Button>
            )}
          </header>

          <main className="flex-1 overflow-hidden">
            <div className="h-full">
              <Switch>
                <ProtectedRoute path="/" component={MessagesPage} />
                <ProtectedRoute path="/messages" component={MessagesPage} />
                <ProtectedRoute path="/servers" component={HomePage} />
                <Route path="/invite/:code" component={InvitePage} />
                <Route path="/auth" component={AuthPage} />
                <Route component={NotFound} />
              </Switch>
            </div>
          </main>
        </div>

        <ProfileSettingsDialog
          isOpen={showProfileSettings}
          onClose={() => setShowProfileSettings(false)}
        />
      </SidebarProvider>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ChannelProvider>
          <Router />
          <NotificationListener />
          <Toaster />
        </ChannelProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;