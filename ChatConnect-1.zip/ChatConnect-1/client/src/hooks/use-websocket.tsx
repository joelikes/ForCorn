import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

export function useWebSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);

  // Get current user ID
  const { data: user, isLoading: isUserLoading } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  useEffect(() => {
    // Only try to connect if we have a user and aren't already connecting/connected
    if (!user?.id || isConnecting || isConnected || isUserLoading) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    setIsConnecting(true);

    const ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      console.log("WebSocket connected");
      setIsConnected(true);
      setSocket(ws);
      setIsConnecting(false);

      // Send identification message when connected
      ws.send(JSON.stringify({
        type: 'identify',
        userId: user.id
      }));
    };

    ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      setIsConnected(false);
      setSocket(null);
      setIsConnecting(false);
    };

    ws.onclose = () => {
      console.log("WebSocket disconnected");
      setIsConnected(false);
      setSocket(null);
      setIsConnecting(false);

      // Try to reconnect after a delay if we still have a user
      if (user?.id) {
        setTimeout(() => {
          setIsConnecting(false);
        }, 5000);
      }
    };

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close();
      }
    };
  }, [user?.id, isConnecting, isConnected, isUserLoading]);

  return socket;
}