import { useEffect, useRef, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

export function useWebSocket() {
  const socket = useRef<WebSocket | null>(null);
  const reconnectAttempts = useRef(0);
  const [isConnecting, setIsConnecting] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const maxReconnectAttempts = 5;
  const baseDelay = 1000; // Start with 1 second delay

  const connect = () => {
    if (isConnecting || socket.current?.readyState === WebSocket.OPEN) return;

    setIsConnecting(true);
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;

    try {
      socket.current = new WebSocket(wsUrl);

      socket.current.onopen = () => {
        console.log('WebSocket connected successfully');
        setIsConnecting(false);
        reconnectAttempts.current = 0;
        toast({
          title: "Connected",
          description: "Real-time connection established",
          duration: 2000,
        });
      };

      socket.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'NOTIFICATION' || data.type === 'INITIAL_NOTIFICATIONS') {
            // Invalidate notifications query to trigger refetch
            queryClient.invalidateQueries({ queryKey: ['/api/notifications/unread'] });
          } else if (data.type === 'ERROR') {
            console.error('WebSocket error message:', data.message);
            toast({
              title: "Connection Error",
              description: data.message,
              variant: "destructive",
            });
          }
        } catch (error) {
          console.error('Failed to parse WebSocket message:', error);
        }
      };

      socket.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast({
          title: "Connection Error",
          description: "Failed to establish real-time connection",
          variant: "destructive",
        });
      };

      socket.current.onclose = (event) => {
        console.log('WebSocket disconnected:', event.code, event.reason);
        setIsConnecting(false);
        socket.current = null;

        // Implement exponential backoff for reconnection
        if (reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 10000);
          console.log(`Attempting to reconnect in ${delay}ms...`);
          reconnectAttempts.current++;

          toast({
            title: "Disconnected",
            description: "Attempting to reconnect...",
            duration: 3000,
          });

          setTimeout(() => {
            if (!socket.current || socket.current.readyState !== WebSocket.OPEN) {
              connect();
            }
          }, delay);
        } else {
          toast({
            title: "Connection Failed",
            description: "Unable to establish real-time connection after multiple attempts",
            variant: "destructive",
          });
        }
      };
    } catch (error) {
      console.error('Failed to create WebSocket connection:', error);
      setIsConnecting(false);
      toast({
        title: "Connection Error",
        description: "Failed to establish WebSocket connection",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    connect();

    return () => {
      if (socket.current) {
        socket.current.close();
        socket.current = null;
      }
    };
  }, []);

  return socket.current;
}