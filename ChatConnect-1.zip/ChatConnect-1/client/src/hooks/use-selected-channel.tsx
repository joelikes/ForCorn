import { create } from 'zustand';

type SelectedChannelStore = {
  selectedServerId: number | null;
  selectedChannelId: number | null;
  setSelectedServer: (serverId: number | null) => void;
  setSelectedChannel: (channelId: number | null) => void;
};

export const useSelectedChannel = create<SelectedChannelStore>((set) => ({
  selectedServerId: null,
  selectedChannelId: null,
  setSelectedServer: (serverId) => set({ selectedServerId: serverId, selectedChannelId: null }),
  setSelectedChannel: (channelId) => set({ selectedChannelId: channelId }),
}));
