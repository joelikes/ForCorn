import { Plus, MessageSquare, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { CreateServerDialog } from "@/components/dialogs/create-server-dialog";
import { JoinServerDialog } from "@/components/dialogs/join-server-dialog";
import { useQuery } from "@tanstack/react-query";
import type { Server } from "@shared/schema";
import { useLocation } from "wouter";
import { useState } from "react";
import { FriendRequestMailbox } from "./friend-request-mailbox";


const DEFAULT_SERVER_ICONS = [
  "https://images.unsplash.com/photo-1683322499436-f4383dd59f5a",
  "https://images.unsplash.com/photo-1687300172792-68a13c4e149a",
  "https://images.unsplash.com/photo-1663932210347-164a05ed0ccd",
  "https://images.unsplash.com/photo-1680691257251-5fead813b73e",
  "https://images.unsplash.com/photo-1666930398504-e747d9155071",
  "https://images.unsplash.com/photo-1506399558188-acca6f8cbf41",
];

export function ServerSidebar() {
  const { selectedServerId, setSelectedServer } = useSelectedChannel();
  const [, setLocation] = useLocation();
  const [joinDialogOpen, setJoinDialogOpen] = useState(false);
  const [createServerOpen, setCreateServerOpen] = useState(false);
  const [inviteCode, setInviteCode] = useState<string>();

  const { data: servers = [] } = useQuery<Server[]>({
    queryKey: ["/api/servers"],
  });

  const handleServerSelect = (serverId: number) => {
    setSelectedServer(serverId);
    setLocation("/servers");
  };

  const handleInvitePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      const match = text.match(/\/invite\/([a-zA-Z0-9]+)/);
      if (match) {
        setInviteCode(match[1]);
        setJoinDialogOpen(true);
      }
    } catch (error) {
      console.error('Failed to read clipboard:', error);
    }
  };

  return (
    <div className="flex h-screen">
      <div className="w-[72px] bg-background border-r flex flex-col h-full">
        <Button
          variant="ghost"
          className="rounded-full w-12 h-12 p-0 mx-auto mt-2 mb-2"
          onClick={() => {
            setSelectedServer(null);
            setLocation("/");
          }}
        >
          <Avatar className="h-12 w-12 bg-primary/10">
            <MessageSquare className="h-6 w-6 text-primary" />
          </Avatar>
        </Button>

        <Separator className="mx-2" />

        <ScrollArea className="flex-1 w-full py-2 px-2">
          <div className="space-y-2">
            {/* Create Server Button */}
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full w-12 h-12"
              onClick={() => setCreateServerOpen(true)}
              title="Create Server"
            >
              <Plus className="h-6 w-6" />
            </Button>

            {/* Separator between create button and server list */}
            <Separator className="my-2" />

            {/* Server List */}
            <div className="space-y-2">
              {servers.map((server) => (
                <Button
                  key={server.id}
                  variant={selectedServerId === server.id ? "secondary" : "ghost"}
                  className="rounded-full w-12 h-12 p-0"
                  onClick={() => handleServerSelect(server.id)}
                >
                  <Avatar className="h-12 w-12">
                    <AvatarImage
                      src={server.icon || DEFAULT_SERVER_ICONS[server.id % DEFAULT_SERVER_ICONS.length]}
                      alt={server.name}
                    />
                  </Avatar>
                </Button>
              ))}
            </div>
          </div>
        </ScrollArea>

        <div className="mt-auto border-t">
          <div className="px-2 py-2">
            <Button
              variant="ghost"
              size="icon"
              className="rounded-full w-12 h-12"
              onClick={handleInvitePaste}
              title="Join Server"
            >
              <UserPlus className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-shrink-0 h-screen overflow-hidden">
        <FriendRequestMailbox />
      </div>

      <JoinServerDialog
        isOpen={joinDialogOpen}
        onClose={() => {
          setJoinDialogOpen(false);
          setInviteCode(undefined);
        }}
        inviteCode={inviteCode}
      />

      <CreateServerDialog
        isOpen={createServerOpen}
        onClose={() => setCreateServerOpen(false)}
      />
    </div>
  );
}