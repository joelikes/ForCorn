import { Hash, Volume2, Settings, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useQuery } from "@tanstack/react-query";
import type { Channel, Server } from "@shared/schema";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { CreateChannelDialog } from "@/components/dialogs/create-channel-dialog";
import { ServerSettingsDialog } from "@/components/dialogs/server-settings-dialog";
import { Loader2 } from "lucide-react";
import { UserControls } from "./user-controls";
import { useState } from "react";
import { FriendRequestMailbox } from "./friend-request-mailbox";
import { MemberList } from "./member-list";

export function ChannelList() {
  const { selectedServerId, selectedChannelId, setSelectedChannel } = useSelectedChannel();
  const [showMailbox, setShowMailbox] = useState(false);

  const { data: channels = [], isLoading: isLoadingChannels } = useQuery<Channel[]>({
    queryKey: [`/api/servers/${selectedServerId}/channels`],
    enabled: !!selectedServerId,
    staleTime: 1000 * 60, // 1 minute
  });

  const { data: server } = useQuery<Server>({
    queryKey: [`/api/servers/${selectedServerId}`],
    enabled: !!selectedServerId,
    staleTime: 1000 * 60, // 1 minute
  });

  if (!selectedServerId) {
    return null;
  }

  if (isLoadingChannels) {
    return (
      <div className="w-80 bg-muted border-r flex items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const textChannels = channels.filter(channel => !channel.isVoice);
  const voiceChannels = channels.filter(channel => channel.isVoice);

  return (
    <div className="w-80 bg-muted border-r flex flex-col h-screen">
      {/* Server Header */}
      <div className="h-12 min-h-[48px] border-b flex items-center px-4 justify-between shrink-0">
        <span className="font-semibold">
          {server?.name || "Unknown Server"}
        </span>
        <div className="flex items-center gap-2">
          <MemberList />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setShowMailbox(!showMailbox)}
          >
            <Mail className="h-4 w-4" />
          </Button>
          {server && <ServerSettingsDialog serverId={server.id} />}
        </div>
      </div>

      {/* Scrollable Channel List */}
      <ScrollArea className="flex-1 overflow-y-auto">
        <div className="px-2 py-4">
          {/* Text Channels */}
          <div className="mb-4">
            <h3 className="px-2 text-xs font-semibold uppercase text-muted-foreground mb-2">
              Text Channels
            </h3>
            <div className="space-y-[2px]">
              {textChannels.map(channel => (
                <Button
                  key={channel.id}
                  variant={selectedChannelId === channel.id ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 px-3"
                  onClick={() => setSelectedChannel(channel.id)}
                >
                  <Hash className="h-4 w-4" />
                  {channel.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Voice Channels */}
          <div className="mb-4">
            <h3 className="px-2 text-xs font-semibold uppercase text-muted-foreground mb-2">
              Voice Channels
            </h3>
            <div className="space-y-[2px]">
              {voiceChannels.map(channel => (
                <Button
                  key={channel.id}
                  variant={selectedChannelId === channel.id ? "secondary" : "ghost"}
                  className="w-full justify-start gap-3 px-3"
                  onClick={() => setSelectedChannel(channel.id)}
                >
                  <Volume2 className="h-4 w-4" />
                  {channel.name}
                </Button>
              ))}
            </div>
          </div>

          {/* Create Channel Button */}
          <div className="px-2">
            {selectedServerId && <CreateChannelDialog serverId={selectedServerId} />}
          </div>
        </div>
      </ScrollArea>

      {/* Fixed Footer */}
      <div className="shrink-0 mt-auto">
        <UserControls />
      </div>

      {/* Friend Request Mailbox */}
      {showMailbox && (
        <div className="absolute left-[72px] top-12 w-80 z-50">
          <FriendRequestMailbox onClose={() => setShowMailbox(false)} />
        </div>
      )}
    </div>
  );
}