import { useQuery } from "@tanstack/react-query";
import { BotMessage, Notification } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card } from "@/components/ui/card";
import { Bell, UserPlus, Mail, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function NotificationCenter() {
  const { toast } = useToast();
  const [filter, setFilter] = useState<'all' | 'friend-requests' | 'bot'>('all');

  // Get bot messages (including friend request notifications)
  const { data: botMessages = [] } = useQuery<BotMessage[]>({
    queryKey: ["/api/bot-messages"],
    refetchInterval: 5000, // Poll every 5 seconds
  });

  // Get general notifications
  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    refetchInterval: 5000,
  });

  const filteredItems = [...notifications, ...botMessages].filter(item => {
    if (filter === 'friend-requests') {
      return 'messageType' in item && item.messageType === 'friend_request';
    }
    if (filter === 'bot') {
      return 'messageType' in item;
    }
    return true;
  }).sort((a, b) => {
    const dateA = new Date('createdAt' in a ? a.createdAt : (a as any).timestamp);
    const dateB = new Date('createdAt' in b ? b.createdAt : (b as any).timestamp);
    return dateB.getTime() - dateA.getTime();
  });

  const handleAcceptFriendRequest = async (requestId: number) => {
    try {
      const response = await apiRequest(
        "POST",
        `/api/friend-requests/${requestId}/respond`,
        { status: "accepted" }
      );

      if (!response.ok) throw new Error("Failed to accept friend request");

      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      queryClient.invalidateQueries({ queryKey: ["/api/bot-messages"] });

      toast({
        title: "Friend Request Accepted",
        description: "You are now friends!",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to accept friend request",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-semibold flex items-center gap-2">
          <Bell className="h-6 w-6" />
          Notifications
        </h2>
        <div className="flex gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            <Bell className="h-4 w-4 mr-2" />
            All
          </Button>
          <Button
            variant={filter === 'friend-requests' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('friend-requests')}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Friend Requests
          </Button>
          <Button
            variant={filter === 'bot' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('bot')}
          >
            <Mail className="h-4 w-4 mr-2" />
            Messages
          </Button>
        </div>
      </div>

      <ScrollArea className="h-[500px] w-full rounded-md border p-4">
        <div className="space-y-4">
          {filteredItems.length > 0 ? (
            filteredItems.map((item, index) => (
              <Card key={index} className="p-4 space-y-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    {'messageType' in item ? (
                      item.messageType === 'friend_request' ? (
                        <UserPlus className="h-5 w-5 text-primary" />
                      ) : (
                        <Mail className="h-5 w-5 text-primary" />
                      )
                    ) : (
                      <Bell className="h-5 w-5 text-primary" />
                    )}
                    <div>
                      <p className="font-medium">
                        {'title' in item ? item.title : 'New Message'}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {'message' in item ? item.message : item.content}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-xs text-muted-foreground flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {format(
                        new Date('createdAt' in item ? item.createdAt : (item as any).timestamp),
                        'MMM d, h:mm a'
                      )}
                    </div>
                    {'messageType' in item && item.messageType === 'friend_request' && (
                      <Button
                        size="sm"
                        onClick={() => {
                          const metadata = item.metadata as { requestId: number };
                          handleAcceptFriendRequest(metadata.requestId);
                        }}
                      >
                        Accept
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center text-muted-foreground py-8">
              <Bell className="h-8 w-8 mb-2" />
              <p>No notifications yet</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}