import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { MessageSquare, Clock } from "lucide-react";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import type { DirectMessage, User } from "@shared/schema";
import { UserProfileDialog } from "@/components/dialogs/user-profile-dialog";
import { UserControls } from "./user-controls";
import { ProfileCard } from "@/components/message/profile-card";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { useLocation } from "wouter";
import { format, formatDistanceToNow } from "date-fns";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function DirectMessageList() {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(() => {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get('userId');
    return userId ? parseInt(userId, 10) : null;
  });
  const [hoveredUserId, setHoveredUserId] = useState<number | null>(null);
  const [showUserProfile, setShowUserProfile] = useState<number | null>(null);
  const { setSelectedChannel } = useSelectedChannel();
  const [, setLocation] = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get('userId');
    if (userId) {
      const parsedId = parseInt(userId, 10);
      setSelectedUserId(parsedId);
      setSelectedChannel(null);
    } else {
      setSelectedUserId(null);
    }
  }, [window.location.search]);

  useEffect(() => {
    setSelectedChannel(null);
  }, []);

  const { data: messages = [], isLoading: isLoadingMessages } = useQuery<DirectMessage[]>({
    queryKey: ["/api/direct-messages"],
    refetchInterval: 36000000,
    staleTime: 36000000,
    refetchOnWindowFocus: false,
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: !!messages?.length,
    staleTime: 36000000,
    refetchOnWindowFocus: false,
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  if (isLoadingMessages) {
    return (
      <div className="w-44 bg-muted border-r flex items-center justify-center">
        <MessageSquare className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  const uniqueConversations = messages.reduce((acc, message) => {
    const otherUserId = message.senderId === currentUser?.id ? message.receiverId : message.senderId;
    const timestamp = new Date(message.timestamp).getTime();

    if (!acc[otherUserId] || timestamp > new Date(acc[otherUserId].lastMessage.timestamp).getTime()) {
      acc[otherUserId] = {
        userId: otherUserId,
        lastMessage: message,
      };
    }
    return acc;
  }, {} as Record<number, { userId: number; lastMessage: DirectMessage }>);

  const sortedConversations = Object.values(uniqueConversations)
    .sort((a, b) =>
      new Date(b.lastMessage.timestamp).getTime() - new Date(a.lastMessage.timestamp).getTime()
    );

  const handleConversationSelect = (userId: number) => {
    if (selectedUserId === userId) {
      setSelectedUserId(null);
      setLocation('/');
    } else {
      setSelectedUserId(userId);
      setSelectedChannel(null);
      setLocation(`/?userId=${userId}`);
    }
  };

  const handleProfileClick = (e: React.MouseEvent, userId: number) => {
    e.stopPropagation();
    setShowUserProfile(userId);
  };

  return (
    <div className="w-64 bg-muted border-r flex flex-col relative">
      <div className="h-10 border-b flex items-center px-2">
        <span className="font-semibold flex items-center gap-1.5 text-sm">
          <MessageSquare className="h-3.5 w-3.5" />
          Direct Messages
        </span>
      </div>

      <div className="flex-1 overflow-y-auto">
        {/* Recent Chats Section */}
        <div className="p-2">
          <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground mb-2">
            <Clock className="h-3 w-3" />
            Recent Chats
          </div>
          <div className="space-y-1">
            {sortedConversations.map(({ userId, lastMessage }) => {
              const otherUser = users?.find((u) => u.id === userId);
              if (!otherUser) return null;

              return (
                <Button
                  key={userId}
                  variant={selectedUserId === userId ? "secondary" : "ghost"}
                  className="w-full justify-start gap-2 px-2 py-2 h-auto"
                  onClick={() => handleConversationSelect(userId)}
                  onMouseEnter={() => setHoveredUserId(userId)}
                  onMouseLeave={() => setHoveredUserId(null)}
                >
                  <Avatar
                    className="h-8 w-8 shrink-0"
                    onClick={(e) => handleProfileClick(e, userId)}
                  >
                    <AvatarImage
                      src={otherUser.avatar || DEFAULT_USER_AVATARS[otherUser.id % DEFAULT_USER_AVATARS.length]}
                      alt={otherUser.username}
                    />
                  </Avatar>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex justify-between items-center">
                      <span className="font-medium truncate text-sm">
                        {otherUser.displayName || otherUser.username}
                      </span>
                    </div>
                    <div className="flex flex-col gap-0.5">
                      <p className="text-xs text-muted-foreground truncate">
                        {lastMessage.content}
                      </p>
                      <span className="text-[10px] text-muted-foreground">
                        {formatDistanceToNow(new Date(lastMessage.timestamp), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </Button>
              );
            })}
          </div>
        </div>
      </div>

      {hoveredUserId && (
        <div className="absolute left-full top-0 ml-2 z-50">
          <ProfileCard
            userId={hoveredUserId}
            isExpanded={true}
            onViewFullProfile={() => setShowUserProfile(hoveredUserId)}
          />
        </div>
      )}

      {showUserProfile !== null && (
        <UserProfileDialog
          userId={showUserProfile}
          isOpen={true}
          onClose={() => setShowUserProfile(null)}
        />
      )}

      <UserControls />
    </div>
  );
}