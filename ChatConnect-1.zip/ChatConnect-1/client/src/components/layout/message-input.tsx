import { useState, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Phone, Video } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";
import { CallDialog } from "@/components/dialogs/call-dialog";

interface MessageInputProps {
  onSendMessage: (content: string, mentions: number[]) => void;
  disabled?: boolean;
  serverId?: number;
  channelId?: number;
  recipientId?: number;
}

export function MessageInput({ 
  onSendMessage, 
  disabled, 
  serverId,
  channelId,
  recipientId 
}: MessageInputProps) {
  const [message, setMessage] = useState("");
  const [showMentions, setShowMentions] = useState(false);
  const [mentionSearch, setMentionSearch] = useState("");
  const [mentionStart, setMentionStart] = useState(-1);
  const [showCallDialog, setShowCallDialog] = useState(false);
  const [callType, setCallType] = useState<"voice" | "video">("voice");
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: users = [] } = useQuery<User[]>({
    queryKey: [`/api/servers/${serverId}/members`],
    enabled: !!serverId && showMentions,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setMessage(newValue);

    const lastAtSymbol = newValue.lastIndexOf('@');
    if (lastAtSymbol !== -1 && lastAtSymbol > mentionStart) {
      setMentionStart(lastAtSymbol);
      setMentionSearch(newValue.slice(lastAtSymbol + 1));
      setShowMentions(true);
    } else if (showMentions && !newValue.includes('@')) {
      setShowMentions(false);
    }
  };

  const handleSelectMention = (e: React.MouseEvent, user: User) => {
    e.preventDefault();
    const beforeMention = message.slice(0, mentionStart);
    const afterMention = message.slice(mentionStart + mentionSearch.length + 1);
    setMessage(`${beforeMention}@${user.username} ${afterMention}`);
    setShowMentions(false);
    inputRef.current?.focus();
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !disabled) {
      const mentions = message.match(/@(\w+)/g)?.map(mention => mention.slice(1)) || [];
      const mentionedUsers = users
        .filter(user => mentions.includes(user.username))
        .map(user => user.id);

      onSendMessage(message.trim(), mentionedUsers);
      setMessage("");
      setShowMentions(false);
    }
  };

  const initiateCall = (type: "voice" | "video") => {
    setCallType(type);
    setShowCallDialog(true);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showMentions && !inputRef.current?.contains(event.target as Node)) {
        setShowMentions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showMentions]);

  const filteredUsers = users.filter(user => {
    if (!user?.username) return false;
    return user.username.toLowerCase().includes(mentionSearch.toLowerCase());
  });

  return (
    <>
      <form onSubmit={handleSubmit} className="relative">
        <div className="flex gap-2">
          {recipientId && (
            <>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => initiateCall("voice")}
                className="shrink-0"
              >
                <Phone className="h-4 w-4" />
              </Button>
              <Button
                type="button"
                size="icon"
                variant="ghost"
                onClick={() => initiateCall("video")}
                className="shrink-0"
              >
                <Video className="h-4 w-4" />
              </Button>
            </>
          )}
          <Input
            ref={inputRef}
            placeholder="Type a message..."
            value={message}
            onChange={handleInputChange}
            className="flex-1"
            disabled={disabled}
          />
          <Button
            type="submit"
            size="icon"
            disabled={!message.trim() || disabled}
            className="shrink-0"
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>

        {showMentions && filteredUsers.length > 0 && (
          <div className="absolute bottom-full left-0 mb-2 w-64 max-h-48 overflow-y-auto bg-background border rounded-md shadow-lg z-50">
            {filteredUsers.map(user => (
              <button
                key={user.id}
                className="w-full px-4 py-2 text-left hover:bg-accent/50 flex items-center gap-2"
                onClick={(e) => handleSelectMention(e, user)}
                type="button"
              >
                {user.username}
              </button>
            ))}
          </div>
        )}
      </form>

      {showCallDialog && recipientId && (
        <CallDialog
          type={callType}
          recipientId={recipientId}
          isOpen={showCallDialog}
          onClose={() => setShowCallDialog(false)}
        />
      )}
    </>
  );
}