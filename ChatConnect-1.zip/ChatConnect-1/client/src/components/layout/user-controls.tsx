import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Mic,
  MicOff,
  Settings,
  Video,
  VideoOff,
  Volume2,
  VolumeX,
  Users,
  LogOut,
  Search,
  User
} from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { SettingsDialog } from "@/components/dialogs/settings-dialog";
import { UserStatusDialog } from "@/components/dialogs/user-status-dialog";
import { FriendListDialog } from "@/components/dialogs/friend-list-dialog";
import { UserSearchDialog } from "@/components/dialogs/user-search-dialog";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
];

const STATUS_COLORS = {
  online: "bg-green-500",
  away: "bg-yellow-500",
  dnd: "bg-red-500",
  busy: "bg-red-500",
  working: "bg-blue-500",
  available: "bg-green-500",
  offline: "bg-gray-500",
};

export function UserControls() {
  const { user, logoutMutation } = useAuth();
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showStatusDialog, setShowStatusDialog] = useState(false);
  const [showFriendList, setShowFriendList] = useState(false);
  const [showSearchDialog, setShowSearchDialog] = useState(false);

  if (!user) return null;

  const currentStatus = user.status || "offline";
  const currentStatusColor = STATUS_COLORS[currentStatus as keyof typeof STATUS_COLORS] || STATUS_COLORS.offline;
  const avatarUrl = user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length];

  const handleLogout = () => {
    if (!logoutMutation.isPending) {
      logoutMutation.mutate();
    }
  };

  return (
    <>
      <div className="mt-auto border-t bg-muted/10">
        <div className="px-2 pt-1">
          <div className="grid grid-cols-2 gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setShowFriendList(true)}
            >
              <Users className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setShowSearchDialog(true)}
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-1 mt-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setIsMuted(!isMuted)}
            >
              {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setIsDeafened(!isDeafened)}
            >
              {isDeafened ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-1 mt-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setVideoEnabled(!videoEnabled)}
            >
              {videoEnabled ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-8 w-8"
              onClick={() => setShowSettings(true)}
            >
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="px-2 py-2 flex items-center gap-2 mt-1 bg-background/50">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative p-0 h-8 w-8">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={avatarUrl} alt={user.username} />
                  <AvatarFallback>
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-background ${currentStatusColor}`} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuItem onClick={() => setShowStatusDialog(true)}>
                Set Status
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <div className="flex-1 min-w-0">
            <div className="font-semibold text-xs truncate">
              {user.displayName || user.username}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {user.customStatus || currentStatus}
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive hover:text-destructive"
            onClick={handleLogout}
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <SettingsDialog 
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
      />

      <UserStatusDialog
        isOpen={showStatusDialog}
        onClose={() => setShowStatusDialog(false)}
      />

      <FriendListDialog
        open={showFriendList}
        onOpenChange={setShowFriendList}
      />

      <UserSearchDialog
        isOpen={showSearchDialog}
        onClose={() => setShowSearchDialog(false)}
      />
    </>
  );
}