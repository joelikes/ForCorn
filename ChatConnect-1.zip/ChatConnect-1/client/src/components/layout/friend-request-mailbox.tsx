import React, { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { EnrichedFriendRequest } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Mail, Loader2, Check, X, AlertCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format, formatDistanceToNow } from "date-fns";
import { UserProfileDialog } from "@/components/dialogs/user-profile-dialog";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

interface FriendRequestMailboxProps {
  onClose?: () => void;
}

export function FriendRequestMailbox({ onClose }: FriendRequestMailboxProps) {
  const { toast } = useToast();
  const [error, setError] = useState<string | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);

  const { data: receivedRequests = [], isLoading: isLoadingRequests } = useQuery<EnrichedFriendRequest[]>({
    queryKey: ["/api/friend-requests/received"],
    refetchInterval: 3000,
  });

  // WebSocket setup for real-time notifications
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'friend_request_expired') {
        queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
        toast({
          title: "Friend Request Expired",
          description: "A friend request has expired and been removed.",
          variant: "default",
        });
      }
    };

    return () => ws.close();
  }, [toast]);

  const handleProfileClick = (userId: number) => {
    setSelectedUserId(userId);
  };

  // Accept friend request mutation
  const acceptRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        action: "accept"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to accept friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });

      const request = receivedRequests.find(r => r.id === requestId);
      toast({
        title: "Friend request accepted",
        description: request?.sender ? `You are now friends with ${request.sender.displayName || request.sender.username}!` : "You are now friends!",
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to accept request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Reject friend request mutation
  const rejectRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        action: "reject"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to reject friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });

      const request = receivedRequests.find(r => r.id === requestId);
      toast({
        title: "Friend request rejected",
        description: request?.sender ? `Rejected request from ${request.sender.displayName || request.sender.username}` : undefined,
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to reject request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <>
      <div className="h-screen flex flex-col bg-card border-r min-w-[280px]">
        {/* Header */}
        <div className="p-2 border-b bg-gradient-to-b from-background/80 to-background/50 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 flex items-center justify-center bg-primary/10 rounded-lg">
              <Mail className="h-4 w-4 text-primary" />
            </div>
            <div>
              <h2 className="text-xs font-semibold text-foreground">Friend Request Mailbox</h2>
              {receivedRequests.length > 0 && (
                <p className="text-xs text-muted-foreground">
                  {receivedRequests.length} new request{receivedRequests.length !== 1 ? 's' : ''}
                </p>
              )}
            </div>
          </div>
          {onClose && (
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7"
              onClick={onClose}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Error Display */}
        {error && (
          <Alert variant="destructive" className="m-2">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto px-2">
          <div className="py-2 space-y-2">
            {isLoadingRequests ? (
              <div className="flex items-center justify-center h-20">
                <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
              </div>
            ) : receivedRequests.length > 0 ? (
              receivedRequests.map((request) => (
                <div
                  key={request.id}
                  className="p-2 border rounded-lg bg-background shadow-sm hover:shadow-md transition-all duration-200"
                >
                  {/* Sender Info */}
                  <div className="flex items-center gap-2 mb-2">
                    <button
                      onClick={() => handleProfileClick(request.senderId)}
                      className="flex items-center gap-2 hover:opacity-80 transition-opacity"
                    >
                      <Avatar className="h-8 w-8 ring-1 ring-border cursor-pointer">
                        <AvatarImage
                          src={request.sender?.avatar || DEFAULT_USER_AVATARS[request.senderId % DEFAULT_USER_AVATARS.length]}
                          alt={request.sender?.username || `User ${request.senderId}`}
                        />
                      </Avatar>
                      <div className="flex-1 min-w-0 text-left">
                        <p className="text-sm font-medium text-foreground truncate hover:underline">
                          {request.sender?.displayName || request.sender?.username || `User ${request.senderId}`}
                        </p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {format(new Date(request.timestamp), 'MMM d, h:mm a')}
                          </p>
                          <span className="text-xs text-amber-500 dark:text-amber-400">
                            Expires {formatDistanceToNow(new Date(request.expiresAt), { addSuffix: true })}
                          </span>
                        </div>
                      </div>
                    </button>
                  </div>

                  {/* Message Preview */}
                  {request.message && (
                    <div className="mb-3 px-2 py-1.5 bg-muted/50 rounded text-xs text-foreground line-clamp-2">
                      {request.message}
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => acceptRequestMutation.mutate(request.id)}
                      disabled={acceptRequestMutation.isPending || rejectRequestMutation.isPending}
                      className="flex-1 h-8 text-xs hover:bg-primary/10 hover:text-primary"
                    >
                      <Check className="h-3 w-3 mr-1" />
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => rejectRequestMutation.mutate(request.id)}
                      disabled={acceptRequestMutation.isPending || rejectRequestMutation.isPending}
                      className="flex-1 h-8 text-xs hover:bg-destructive/10 hover:text-destructive"
                    >
                      <X className="h-3 w-3 mr-1" />
                      Ignore
                    </Button>
                  </div>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center h-20 text-muted-foreground">
                <Mail className="h-5 w-5 mb-1" />
                <p className="text-xs">No new requests</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {selectedUserId !== null && (
        <UserProfileDialog
          userId={selectedUserId}
          isOpen={true}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </>
  );
}