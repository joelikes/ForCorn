import { useRef, useEffect, useState } from "react";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Message, type User, type Channel, type MessageReaction, type DirectMessage } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { format } from "date-fns";
import { MessageReactions } from "@/components/message/message-reactions";
import { UserProfileDialog } from "@/components/dialogs/user-profile-dialog";
import { useLocation } from "wouter";
import { ProfileCard } from "@/components/message/profile-card";
import { MessageSquare, Users, Server, Activity, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function MessageArea() {
  const { toast } = useToast();
  const { selectedServerId, selectedChannelId, setSelectedChannel } = useSelectedChannel();
  const scrollAreaRef = useRef<HTMLDivElement>(null);
  const [hoveredUserId, setHoveredUserId] = useState<number | null>(null);
  const [viewingProfileUserId, setViewingProfileUserId] = useState<number | null>(null);
  const [selectedProfileUserId, setSelectedProfileUserId] = useState<number | null>(() => {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get('userId');
    return userId ? parseInt(userId, 10) : null;
  });
  const [message, setMessage] = useState("");
  const { user: currentUser } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const userId = params.get('userId');
    if (userId) {
      const parsedId = parseInt(userId, 10);
      setSelectedProfileUserId(parsedId);
      setSelectedChannel(null);
    }
  }, [window.location.search]);

  const { data: directMessages = [], isLoading: isLoadingMessages } = useQuery<DirectMessage[]>({
    queryKey: [`/api/direct-messages/${selectedProfileUserId}`],
    enabled: !selectedServerId && !selectedChannelId && !!selectedProfileUserId,
    refetchInterval: 5000,
    staleTime: 2000,
  });

  const { data: channelMessages = [] } = useQuery<Message[]>({
    queryKey: [`/api/channels/${selectedChannelId}/messages`],
    enabled: !!selectedChannelId,
  });

  const { data: otherUser } = useQuery<User>({
    queryKey: [`/api/users/${selectedProfileUserId}`],
    enabled: !selectedServerId && !!selectedProfileUserId,
  });

  const sendDirectMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      if (!selectedProfileUserId) throw new Error("No recipient selected");
      const res = await apiRequest("POST", `/api/direct-messages/${selectedProfileUserId}`, {
        content,
      });
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error || 'Failed to send message');
      }
      return res.json();
    },
    onMutate: async (newMessage) => {
      await queryClient.cancelQueries({ queryKey: [`/api/direct-messages/${selectedProfileUserId}`] });

      const optimisticMessage: DirectMessage = {
        id: Math.random(),
        content: newMessage,
        senderId: currentUser?.id || 0,
        receiverId: selectedProfileUserId || 0,
        timestamp: new Date(),
      };

      queryClient.setQueryData<DirectMessage[]>(
        [`/api/direct-messages/${selectedProfileUserId}`],
        old => [...(old || []), optimisticMessage]
      );

      return { optimisticMessage };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/direct-messages/${selectedProfileUserId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/direct-messages"] });
      setMessage("");

      // Scroll to bottom after sending
      if (scrollAreaRef.current) {
        scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
      }
    },
    onError: (error: Error, newItem, context) => {
      toast({
        title: "Failed to send message",
        description: error.message,
        variant: "destructive",
      });

      if (context?.optimisticMessage) {
        queryClient.setQueryData<DirectMessage[]>(
          [`/api/direct-messages/${selectedProfileUserId}`],
          old => (old || []).filter(msg => msg.id !== context.optimisticMessage.id)
        );
      }
    },
  });

  const sendChannelMessageMutation = useMutation({
    mutationFn: async ({ content, mentions }: { content: string; mentions: number[] }) => {
      if (!selectedChannelId) throw new Error("No channel selected");
      const res = await apiRequest("POST", `/api/channels/${selectedChannelId}/messages`, {
        content,
        mentions,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannelId}/messages`] });
      setMessage("");
    },
  });

  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollArea = scrollAreaRef.current;
      scrollArea.scrollTop = scrollArea.scrollHeight;
    }
  }, [channelMessages, directMessages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    try {
      if (selectedChannelId) {
        await sendChannelMessageMutation.mutateAsync({ content: message.trim(), mentions: [] });
      } else if (selectedProfileUserId) {
        await sendDirectMessageMutation.mutateAsync(message.trim());
      }
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const messages = selectedChannelId ? channelMessages : directMessages;
  const sortedMessages = [...messages].sort((a, b) =>
    new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  const isDirect = !selectedServerId;
  const headerTitle = isDirect
    ? `Chat with ${otherUser?.displayName || otherUser?.username || 'User'}`
    : selectedChannelId
      ? "Loading..."
      : "Select a conversation";

  const handleCloseChat = () => {
    setLocation('/');
    setSelectedProfileUserId(null);
  };

  return (
    <div className="flex flex-col h-full w-full bg-background">
      <div className="flex items-center justify-between px-4 h-12 min-h-[48px] border-b shrink-0">
        <div className="flex items-center gap-3">
          {isDirect && otherUser && (
            <Avatar className="h-8 w-8">
              <AvatarImage
                src={otherUser.avatar || DEFAULT_USER_AVATARS[otherUser.id % DEFAULT_USER_AVATARS.length]}
                alt={otherUser.username}
              />
            </Avatar>
          )}
          <div>
            <h2 className="font-semibold">{headerTitle}</h2>
            {isDirect && otherUser?.activityStatus && (
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Activity className="h-3 w-3" />
                {otherUser.activityStatus}
              </p>
            )}
          </div>
        </div>
        {isDirect && (
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCloseChat}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      <div className="flex-1 overflow-hidden">
        <div className="h-full overflow-y-auto" ref={scrollAreaRef}>
          {!selectedChannelId && !selectedProfileUserId ? (
            <div className="h-full flex items-center justify-center p-8">
              <div className="max-w-md text-center space-y-6">
                <div className="flex flex-col items-center gap-4">
                  <MessageSquare className="h-16 w-16 text-primary/20" />
                  <h2 className="text-2xl font-semibold">Start a Conversation!</h2>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Users className="h-5 w-5" />
                    <p className="text-left">
                      Message your friends directly by clicking their profile or selecting them from your friends list
                    </p>
                  </div>
                  <div className="flex items-center gap-3 text-muted-foreground">
                    <Server className="h-5 w-5" />
                    <p className="text-left">
                      Join servers to discover new communities and make friends
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 space-y-4">
              {sortedMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground space-y-2">
                  <MessageSquare className="h-12 w-12 text-primary/20" />
                  <p>No messages yet</p>
                  <p className="text-sm">Start the conversation!</p>
                </div>
              ) : (
                sortedMessages.map((msg) => {
                  const isCurrentUser = ('userId' in msg ? msg.userId : msg.senderId) === currentUser?.id;
                  const userId = isCurrentUser ? currentUser?.id : ('userId' in msg ? msg.userId : msg.senderId);
                  const user = isCurrentUser ? currentUser : otherUser;
                  const username = user?.username || `User ${userId}`;
                  const displayName = user?.displayName || username;

                  return (
                    <div
                      key={msg.id}
                      className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : ''}`}
                    >
                      <Avatar
                        className="h-8 w-8 mt-1 flex-shrink-0 cursor-pointer"
                        onClick={() => setViewingProfileUserId(userId)}
                      >
                        <AvatarImage
                          src={user?.avatar || DEFAULT_USER_AVATARS[userId % DEFAULT_USER_AVATARS.length]}
                          alt={username}
                        />
                      </Avatar>
                      <div className={`flex-1 max-w-[80%] ${isCurrentUser ? 'items-end' : 'items-start'}`}>
                        <button
                          onClick={() => setViewingProfileUserId(userId)}
                          className={`text-sm font-semibold hover:underline mb-1 ${
                            isCurrentUser ? 'text-right w-full' : ''
                          }`}
                        >
                          {displayName}
                        </button>
                        <div
                          className={`rounded-lg px-4 py-2 ${
                            isCurrentUser
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <p className="text-sm break-words">{msg.content}</p>
                        </div>
                        <div className={`flex items-center gap-2 mt-1 ${
                          isCurrentUser ? 'justify-end' : ''
                        }`}>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(msg.timestamp), "h:mm a")}
                          </span>
                          {!isDirect && 'channelId' in msg && (
                            <MessageReactions messageId={msg.id} reactions={[]} />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}
        </div>
      </div>

      {(selectedChannelId || selectedProfileUserId) && (
        <div className="shrink-0 border-t p-4 bg-background">
          <form onSubmit={handleSubmit}>
            <div className="flex gap-2">
              <Input
                placeholder={`Message ${isDirect ? otherUser?.username || 'User' : 'channel'}...`}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1"
                autoFocus
              />
              <Button
                type="submit"
                disabled={!message.trim() || sendChannelMessageMutation.isPending || sendDirectMessageMutation.isPending}
              >
                Send
              </Button>
            </div>
          </form>
        </div>
      )}

      {viewingProfileUserId && (
        <UserProfileDialog
          userId={viewingProfileUserId}
          isOpen={true}
          onClose={() => setViewingProfileUserId(null)}
        />
      )}
    </div>
  );
}