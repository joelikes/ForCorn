import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { EnrichedFriendRequest } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Mail, Loader2, Check, X, AlertCircle, Clock, Mail as MailIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { format } from "date-fns";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function FriendRequestSection() {
  const { toast } = useToast();
  const [error, setError] = React.useState<string | null>(null);

  // Get pending friend requests with shorter polling interval
  const { data: receivedRequests = [], isLoading: isLoadingRequests } = useQuery<EnrichedFriendRequest[]>({
    queryKey: ["/api/friend-requests/received"],
    refetchInterval: 3000, // Poll every 3 seconds
  });

  // Debug logging to verify data
  React.useEffect(() => {
    console.log('Current requests:', receivedRequests);
  }, [receivedRequests]);

  const acceptRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        action: "accept"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to accept friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });

      const request = receivedRequests.find(r => r.id === requestId);
      toast({
        title: "Friend request accepted",
        description: request?.sender ? `You are now friends with ${request.sender.displayName || request.sender.username}!` : "You are now friends!",
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to accept request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const rejectRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        action: "reject"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to reject friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });

      const request = receivedRequests.find(r => r.id === requestId);
      toast({
        title: "Friend request rejected",
        description: request?.sender ? `Rejected request from ${request.sender.displayName || request.sender.username}` : undefined,
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to reject request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="flex-1 flex flex-col min-h-0 bg-card">
      {/* Mailbox Header */}
      <div className="p-6 border-b bg-gradient-to-b from-background/80 to-background/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 flex items-center justify-center bg-primary/10 rounded-lg">
              <Mail className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">Friend Request Mailbox</h2>
              <p className="text-sm text-muted-foreground">Manage your incoming friend requests</p>
            </div>
          </div>
          {receivedRequests.length > 0 && (
            <span className="px-2.5 py-0.5 text-sm font-medium bg-primary text-primary-foreground rounded-full">
              {receivedRequests.length} new
            </span>
          )}
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <Alert variant="destructive" className="m-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Mailbox Content */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {isLoadingRequests ? (
            <div className="flex items-center justify-center h-[200px]">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : receivedRequests.length > 0 ? (
            receivedRequests.map((request) => (
              <div
                key={request.id}
                className="group relative p-4 border rounded-lg bg-background shadow-sm hover:shadow-md transition-all duration-200 hover:bg-accent/5"
              >
                {/* Mail Icon Overlay */}
                <div className="absolute right-4 top-4 text-muted-foreground/20">
                  <MailIcon className="h-12 w-12" />
                </div>

                {/* Request Content */}
                <div className="relative">
                  {/* Sender Info */}
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 ring-2 ring-background">
                      <AvatarImage
                        src={request.sender?.avatar || DEFAULT_USER_AVATARS[request.senderId % DEFAULT_USER_AVATARS.length]}
                        alt={request.sender?.username || `User ${request.senderId}`}
                      />
                    </Avatar>
                    <div>
                      <p className="font-medium text-foreground">
                        {request.sender?.displayName || request.sender?.username || `User ${request.senderId}`}
                      </p>
                      <p className="text-sm text-muted-foreground flex items-center gap-1">
                        @{request.sender?.username} • <Clock className="h-3 w-3" />
                        {format(new Date(request.timestamp), 'MMM d, h:mm a')}
                      </p>
                    </div>
                  </div>

                  {/* Request Message */}
                  {request.message && (
                    <div className="mt-3 p-3 bg-muted/50 rounded-md border border-border/50">
                      <p className="text-sm text-foreground whitespace-pre-wrap">{request.message}</p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex justify-end gap-2 mt-4">
                    <Button
                      size="sm"
                      onClick={() => acceptRequestMutation.mutate(request.id)}
                      disabled={acceptRequestMutation.isPending || rejectRequestMutation.isPending}
                      className="bg-primary text-primary-foreground hover:bg-primary/90"
                    >
                      {acceptRequestMutation.isPending && acceptRequestMutation.variables === request.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <Check className="h-4 w-4 mr-2" />
                          Accept
                        </>
                      )}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => rejectRequestMutation.mutate(request.id)}
                      disabled={acceptRequestMutation.isPending || rejectRequestMutation.isPending}
                      className="border-border hover:bg-destructive hover:text-destructive-foreground"
                    >
                      {rejectRequestMutation.isPending && rejectRequestMutation.variables === request.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          <X className="h-4 w-4 mr-2" />
                          Ignore
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-[200px] text-muted-foreground gap-2">
              <div className="h-16 w-16 flex items-center justify-center bg-muted rounded-full">
                <Mail className="h-8 w-8" />
              </div>
              <p className="text-base font-medium">Your mailbox is empty</p>
              <p className="text-sm">Friend requests you receive will appear here</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}