import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Crown, Users } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { ServerMember, User } from "@shared/schema";
import { useState } from "react";
import { UserProfileDialog } from "@/components/dialogs/user-profile-dialog";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
  "https://images.unsplash.com/photo-1507499036636-f716246c2c23",
  "https://images.unsplash.com/photo-1601388352547-2802c6f32eb8",
  "https://images.unsplash.com/photo-1581291518570-03a26006fb21",
  "https://images.unsplash.com/photo-1633466154054-399bf16156a2",
];

interface MemberItemProps {
  member: ServerMember;
  user: User;
  onProfileClick: (userId: number) => void;
}

function MemberItem({ member, user, onProfileClick }: MemberItemProps) {
  return (
    <button 
      className="flex items-center gap-2 px-2 py-1 rounded hover:bg-muted/50 cursor-pointer w-full text-left"
      onClick={() => onProfileClick(user.id)}
    >
      <Avatar className="h-8 w-8">
        <AvatarImage
          src={user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length]}
          alt={user.username}
        />
      </Avatar>
      <span className="text-sm font-medium flex-1 min-w-0 truncate">
        {user.displayName || user.username}
      </span>
      {member.isAdmin && (
        <Crown className="h-4 w-4 text-yellow-500 flex-shrink-0" />
      )}
    </button>
  );
}

export function MemberList() {
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const { selectedServerId } = useSelectedChannel();
  const [isOpen, setIsOpen] = useState(false);

  const { data: members = [] } = useQuery<ServerMember[]>({
    queryKey: [`/api/servers/${selectedServerId}/members`],
    enabled: !!selectedServerId,
  });

  const { data: users = [] } = useQuery<User[]>({
    queryKey: [`/api/servers/${selectedServerId}/members`],
    enabled: !!selectedServerId,
  });

  const adminMembers = members.filter((member) => member.isAdmin);
  const regularMembers = members.filter((member) => !member.isAdmin);

  if (!selectedServerId) {
    return null;
  }

  const memberCount = members.length;

  return (
    <div className="flex items-center">
      <Sheet open={isOpen} onOpenChange={setIsOpen}>
        <SheetTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-7 px-2 gap-2"
          >
            <Users className="h-4 w-4" />
            <span className="text-xs">{memberCount}</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-[240px] p-0">
          <ScrollArea className="flex-1 px-2 py-3">
            {adminMembers.length > 0 && (
              <div className="mb-4">
                <h4 className="text-xs font-semibold text-muted-foreground uppercase px-2 mb-2">
                  Admins
                </h4>
                {adminMembers.map((member) => {
                  const user = users.find((u) => u.id === member.userId);
                  if (!user) return null;
                  return (
                    <MemberItem 
                      key={member.id} 
                      member={member} 
                      user={user} 
                      onProfileClick={setSelectedUserId}
                    />
                  );
                })}
              </div>
            )}
            {regularMembers.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold text-muted-foreground uppercase px-2 mb-2">
                  Members
                </h4>
                {regularMembers.map((member) => {
                  const user = users.find((u) => u.id === member.userId);
                  if (!user) return null;
                  return (
                    <MemberItem 
                      key={member.id} 
                      member={member} 
                      user={user}
                      onProfileClick={setSelectedUserId}
                    />
                  );
                })}
              </div>
            )}
          </ScrollArea>
        </SheetContent>
      </Sheet>

      {selectedUserId && (
        <UserProfileDialog
          userId={selectedUserId}
          isOpen={true}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </div>
  );
}