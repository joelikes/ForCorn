import { UserPlus, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useState } from "react"
import { AddFriendDialog } from "@/components/dialogs/add-friend-dialog"
import { FriendListDialog } from "@/components/dialogs/friend-list-dialog"
import { FriendRequestSection } from "./friend-request-section"

export function FriendSection() {
  const [showAddFriend, setShowAddFriend] = useState(false)
  const [showFriendList, setShowFriendList] = useState(false)

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 space-y-2 border-b">
        <h2 className="text-lg font-semibold mb-4">Friends</h2>
        <div className="space-y-2">
          <Button 
            variant="outline" 
            className="w-full justify-start" 
            onClick={() => setShowAddFriend(true)}
          >
            <UserPlus className="h-4 w-4 mr-2" />
            Add Friend
          </Button>
          <Button 
            variant="outline" 
            className="w-full justify-start"
            onClick={() => setShowFriendList(true)}
          >
            <Users className="h-4 w-4 mr-2" />
            Friend List
          </Button>
        </div>
      </div>

      {/* Friend Request Section */}
      <div className="flex-1 overflow-hidden">
        <FriendRequestSection />
      </div>

      <AddFriendDialog
        open={showAddFriend}
        onOpenChange={setShowAddFriend}
      />
      <FriendListDialog
        open={showFriendList}
        onOpenChange={setShowFriendList}
      />
    </div>
  )
}