import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useWebSocket } from "@/hooks/use-websocket";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, UserPlus } from "lucide-react";

export function NotificationListener() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const socket = useWebSocket();
  const [connectionError, setConnectionError] = useState<string | null>(null);

  useEffect(() => {
    if (!socket) {
      setConnectionError("Waiting for connection...");
      return;
    }

    setConnectionError(null);

    const handleMessage = (event: MessageEvent) => {
      try {
        const notification = JSON.parse(event.data);

        if (notification.type === 'friend_request') {
          // Play a notification sound
          const audio = new Audio('/notification.mp3');
          audio.play().catch(() => {
            // Ignore audio play errors
          });

          toast({
            title: (
              <div className="flex items-center gap-2">
                <UserPlus className="h-5 w-5 text-primary" />
                {notification.title}
              </div>
            ),
            description: (
              <div className="mt-2 space-y-4">
                <p>{notification.message}</p>
                <div className="flex gap-2">
                  <Button
                    variant="default"
                    size="sm"
                    onClick={async () => {
                      try {
                        await apiRequest(
                          "POST",
                          `/api/friend-requests/${notification.data.requestId}/respond`,
                          { status: "accepted" }
                        );
                        queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
                        toast({
                          title: "Friend Request Accepted",
                          description: `You are now friends with @${notification.data.sender.username}!`,
                        });
                      } catch (error) {
                        toast({
                          title: "Error",
                          description: "Failed to accept friend request",
                          variant: "destructive",
                        });
                      }
                    }}
                  >
                    Accept
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={async () => {
                      try {
                        await apiRequest(
                          "POST",
                          `/api/friend-requests/${notification.data.requestId}/respond`,
                          { status: "rejected" }
                        );
                        queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
                        queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread"] });
                        toast({
                          title: "Friend Request Rejected",
                          description: `Rejected friend request from @${notification.data.sender.username}`,
                        });
                      } catch (error) {
                        toast({
                          title: "Error",
                          description: "Failed to reject friend request",
                          variant: "destructive",
                        });
                      }
                    }}
                  >
                    Reject
                  </Button>
                </div>
              </div>
            ),
            duration: 10000, // Show for 10 seconds
          });
        }
      } catch (error) {
        console.error('Failed to parse notification:', error);
        setConnectionError("Error processing notification");

        // Show error toast to user
        toast({
          title: "Notification Error",
          description: "Failed to process incoming notification",
          variant: "destructive",
        });
      }
    };

    socket.addEventListener('message', handleMessage);

    socket.addEventListener('error', () => {
      setConnectionError("Connection error occurred");
    });

    socket.addEventListener('close', () => {
      setConnectionError("Connection lost. Reconnecting...");
    });

    return () => {
      socket.removeEventListener('message', handleMessage);
    };
  }, [toast, queryClient, socket]);

  // Render connection status alert if there's an error
  if (connectionError) {
    return (
      <Alert variant="destructive" className="fixed bottom-4 right-4 max-w-md">
        <AlertDescription className="flex items-center gap-2">
          {connectionError === "Waiting for connection..." ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : null}
          {connectionError}
        </AlertDescription>
      </Alert>
    );
  }

  return null;
}