import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";
import { Loader2, MessageSquare } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useLocation } from "wouter";
import { useState, useEffect } from "react";
import { useSelectedChannel } from "@/hooks/use-selected-channel";

type FriendListDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function FriendListDialog({ open, onOpenChange }: FriendListDialogProps) {
  const [, setLocation] = useLocation();
  const { setSelectedChannel } = useSelectedChannel();

  useEffect(() => {
    const handleOpenFriendList = () => {
      onOpenChange(true);
    };

    window.addEventListener('open-friend-list', handleOpenFriendList);
    return () => window.removeEventListener('open-friend-list', handleOpenFriendList);
  }, [onOpenChange]);

  const { data: friends = [], isLoading } = useQuery<User[]>({
    queryKey: ["/api/friends"],
    enabled: open,
    staleTime: 30000,
    refetchOnWindowFocus: false,
  });

  const handleMessageClick = (userId: number) => {
    onOpenChange(false);
    setSelectedChannel(null);
    setLocation(`/?userId=${userId}`);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Friends</DialogTitle>
        </DialogHeader>
        <ScrollArea className="max-h-[400px]">
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : friends.length > 0 ? (
            <div className="space-y-4">
              {friends.map((friend) => (
                <div
                  key={friend.id}
                  className="flex items-center justify-between p-2 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarImage
                        src={friend.avatar || DEFAULT_USER_AVATARS[friend.id % DEFAULT_USER_AVATARS.length]}
                        alt={friend.username}
                      />
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {friend.displayName || friend.username}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        @{friend.username}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="flex items-center gap-2"
                    onClick={() => handleMessageClick(friend.id)}
                  >
                    <MessageSquare className="h-4 w-4" />
                    Message
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              No friends yet
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}