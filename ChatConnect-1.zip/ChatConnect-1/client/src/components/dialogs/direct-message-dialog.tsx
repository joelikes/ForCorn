import { useState, useEffect, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Send, Maximize2, Minimize2, Activity, MessageSquare } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { DirectMessage, User } from "@shared/schema";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { MessageReactions } from "@/components/message/message-reactions";

interface DirectMessageDialogProps {
  recipientId: number;
  recipientName: string;
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function DirectMessageDialog({
  recipientId,
  recipientName,
  isOpen,
  onClose,
}: DirectMessageDialogProps) {
  const [message, setMessage] = useState("");
  const [isFullScreen, setIsFullScreen] = useState(false);
  const { user: currentUser } = useAuth();
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const { data: messages = [] } = useQuery<DirectMessage[]>({
    queryKey: [`/api/direct-messages/${recipientId}`],
    enabled: isOpen && !!recipientId,
    staleTime: 15000, // Cache for 15 seconds
    refetchInterval: 30000, // Refresh every 30 seconds
    refetchOnWindowFocus: false, // Prevent refetch on window focus
  });

  const { data: recipient } = useQuery<User>({
    queryKey: [`/api/users/${recipientId}`],
    enabled: isOpen && !!recipientId,
    staleTime: 60000, // Cache user data for 1 minute
    refetchOnWindowFocus: false,
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const res = await apiRequest("POST", `/api/direct-messages/${recipientId}`, {
        content,
      });
      if (!res.ok) {
        throw new Error('Failed to send message');
      }
      return res.json();
    },
    onMutate: async (newMessage) => {
      await queryClient.cancelQueries({ queryKey: [`/api/direct-messages/${recipientId}`] });

      const optimisticMessage: DirectMessage = {
        id: Math.random(),
        content: newMessage,
        senderId: currentUser?.id || 0,
        receiverId: recipientId,
        timestamp: new Date(),
      };

      queryClient.setQueryData<DirectMessage[]>(
        [`/api/direct-messages/${recipientId}`],
        old => [...(old || []), optimisticMessage]
      );

      return { optimisticMessage };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/direct-messages/${recipientId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/direct-messages"] });
      setMessage("");
    },
    onError: (error, newItem, context) => {
      if (context?.optimisticMessage) {
        queryClient.setQueryData<DirectMessage[]>(
          [`/api/direct-messages/${recipientId}`],
          old => (old || []).filter(msg => msg.id !== context.optimisticMessage.id)
        );
      }
    }
  });

  useEffect(() => {
    if (scrollAreaRef.current) {
      const scrollArea = scrollAreaRef.current;
      scrollArea.scrollTop = scrollArea.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && !sendMessageMutation.isPending) {
      sendMessageMutation.mutate(message.trim());
    }
  };

  const sortedMessages = [...messages].sort(
    (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`${isFullScreen ? 'w-screen h-screen max-w-none m-0 rounded-none' : 'sm:max-w-[500px] h-[600px]'} flex flex-col p-0`}
      >
        <DialogHeader className="border-b px-4 py-2">
          <div className="flex justify-between items-center">
            <DialogTitle className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage
                  src={recipient?.avatar || DEFAULT_USER_AVATARS[recipientId % DEFAULT_USER_AVATARS.length]}
                  alt={recipientName}
                />
              </Avatar>
              <div className="flex flex-col">
                <span className="font-semibold">{recipientName}</span>
                {recipient?.activityStatus && (
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <Activity className="h-3 w-3" />
                    {recipient.activityStatus}
                  </span>
                )}
              </div>
            </DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleFullScreen}
              className="ml-auto"
            >
              {isFullScreen ? (
                <Minimize2 className="h-4 w-4" />
              ) : (
                <Maximize2 className="h-4 w-4" />
              )}
            </Button>
          </div>
        </DialogHeader>
        <ScrollArea className="flex-1" ref={scrollAreaRef}>
          {sortedMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-muted-foreground space-y-2">
              <MessageSquare className="h-12 w-12 text-primary/20" />
              <p>No messages yet</p>
              <p className="text-sm">Start a conversation with {recipientName}!</p>
            </div>
          ) : (
            <div className="space-y-4 p-4">
              {sortedMessages.map((msg) => {
                const isCurrentUser = msg.senderId === currentUser?.id;
                return (
                  <div
                    key={msg.id}
                    className={`flex gap-3 ${isCurrentUser ? 'flex-row-reverse' : ''}`}
                  >
                    <Avatar className="h-8 w-8 mt-1 flex-shrink-0">
                      <AvatarImage
                        src={
                          isCurrentUser
                            ? currentUser?.avatar || DEFAULT_USER_AVATARS[currentUser.id % DEFAULT_USER_AVATARS.length]
                            : recipient?.avatar || DEFAULT_USER_AVATARS[recipientId % DEFAULT_USER_AVATARS.length]
                        }
                        alt={isCurrentUser ? currentUser?.username : recipientName}
                      />
                    </Avatar>
                    <div
                      className={`flex-1 max-w-[80%] ${
                        isCurrentUser ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`rounded-lg px-4 py-2 ${
                          isCurrentUser
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}
                      >
                        <p className="text-sm break-words">{msg.content}</p>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(msg.timestamp), "h:mm a")}
                        </span>
                        <MessageReactions messageId={msg.id} reactions={[]} />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </ScrollArea>
        <form onSubmit={handleSubmit} className="flex gap-2 p-4 border-t">
          <Input
            placeholder={`Message ${recipientName}...`}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="flex-1"
            autoFocus
          />
          <Button
            type="submit"
            size="icon"
            disabled={!message.trim() || sendMessageMutation.isPending}
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}