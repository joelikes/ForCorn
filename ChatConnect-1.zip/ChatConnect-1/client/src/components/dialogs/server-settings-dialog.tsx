import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Role, User, Server } from "@shared/schema";
import { Settings, Copy, Trash2 } from "lucide-react";
import { PermissionFlags } from "@shared/schema";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";

interface ServerSettingsDialogProps {
  serverId: number;
}

// Convert permission flags to a readable format
const PERMISSION_LABELS: Record<keyof typeof PermissionFlags, string> = {
  MANAGE_SERVER: "Manage Server",
  MANAGE_ROLES: "Manage Roles",
  MANAGE_CHANNELS: "Manage Channels",
  KICK_MEMBERS: "Kick Members",
  BAN_MEMBERS: "Ban Members",
  MANAGE_MESSAGES: "Manage Messages",
  SEND_MESSAGES: "Send Messages",
  READ_MESSAGES: "Read Messages",
  ATTACH_FILES: "Attach Files",
  CONNECT_VOICE: "Connect to Voice",
  SPEAK: "Speak in Voice",
};

export function ServerSettingsDialog({ serverId }: ServerSettingsDialogProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isCreatingRole, setIsCreatingRole] = useState(false);
  const [newRoleName, setNewRoleName] = useState("");
  const [newRoleColor, setNewRoleColor] = useState("#000000");
  const [selectedPermissions, setSelectedPermissions] = useState<number[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: roles = [] } = useQuery<Role[]>({
    queryKey: [`/api/servers/${serverId}/roles`],
    enabled: isOpen,
  });

  const { data: members = [] } = useQuery<User[]>({
    queryKey: [`/api/servers/${serverId}/members`],
    enabled: isOpen,
  });

  const { data: server } = useQuery<Server>({
    queryKey: [`/api/servers/${serverId}`],
    enabled: isOpen,
  });

  const { data: currentUserRoles = [] } = useQuery<Role[]>({
    queryKey: [`/api/servers/${serverId}/users/${server?.ownerId}/roles`],
    enabled: !!server?.ownerId,
  });

  const hasPermission = (flag: number) => {
    return server?.ownerId !== undefined && (server?.ownerId === user?.id || currentUserRoles.some(role =>
      role.permissions.includes(PermissionFlags.MANAGE_ROLES)
    ));
  };

  const createRoleMutation = useMutation({
    mutationFn: async () => {
      if (!hasPermission(PermissionFlags.MANAGE_ROLES)) {
        throw new Error("You don't have permission to create roles");
      }

      const res = await apiRequest("POST", `/api/servers/${serverId}/roles`, {
        name: newRoleName,
        color: newRoleColor,
        permissions: selectedPermissions,
        position: roles.length,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${serverId}/roles`] });
      setIsCreatingRole(false);
      setNewRoleName("");
      setNewRoleColor("#000000");
      setSelectedPermissions([]);
      toast({
        title: "Role created",
        description: "The role has been created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create role",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const assignRoleMutation = useMutation({
    mutationFn: async ({ userId, roleId }: { userId: number; roleId: number }) => {
      if (!hasPermission(PermissionFlags.MANAGE_ROLES)) {
        throw new Error("You don't have permission to assign roles");
      }

      const res = await apiRequest(
        "POST",
        `/api/servers/${serverId}/users/${userId}/roles`,
        { roleId }
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/servers/${serverId}/roles`] });
      toast({
        title: "Role assigned",
        description: "The role has been assigned successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to assign role",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generateInviteMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/servers/${serverId}/invites`);
      return res.json();
    },
    onSuccess: (invite) => {
      const inviteLink = `${window.location.origin}/invite/${invite.code}`;
      navigator.clipboard.writeText(inviteLink);
      toast({
        title: "Invite link copied",
        description: "The server invite link has been copied to your clipboard",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to generate invite",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const togglePermission = (permission: number) => {
    setSelectedPermissions(current =>
      current.includes(permission)
        ? current.filter(p => p !== permission)
        : [...current, permission]
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon">
          <Settings className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Server Settings</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="roles" className="mt-4">
          <TabsList>
            <TabsTrigger value="roles">Roles</TabsTrigger>
            <TabsTrigger value="permissions">Permissions</TabsTrigger>
            <TabsTrigger value="members">Members</TabsTrigger>
            <TabsTrigger value="invite">Invite</TabsTrigger>
            {server?.ownerId !== undefined && server?.ownerId === user?.id && (
              <TabsTrigger value="danger" className="text-destructive">
                Danger Zone
              </TabsTrigger>
            )}
          </TabsList>
          <TabsContent value="roles" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Roles</h3>
              {roles.map((role) => (
                <div
                  key={role.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div>
                    <p className="font-medium" style={{ color: role.color || undefined }}>
                      {role.name}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {role.isAdmin ? "Administrator" : "Member"}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    Edit
                  </Button>
                </div>
              ))}
              {!isCreatingRole ? (
                <Button
                  onClick={() => setIsCreatingRole(true)}
                  disabled={!hasPermission(PermissionFlags.MANAGE_ROLES)}
                >
                  Create Role
                </Button>
              ) : (
                <div className="space-y-4 border rounded-lg p-4">
                  <div className="space-y-2">
                    <Label htmlFor="roleName">Role Name</Label>
                    <Input
                      id="roleName"
                      value={newRoleName}
                      onChange={(e) => setNewRoleName(e.target.value)}
                      placeholder="Enter role name..."
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="roleColor">Role Color</Label>
                    <Input
                      id="roleColor"
                      type="color"
                      value={newRoleColor}
                      onChange={(e) => setNewRoleColor(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Permissions</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {Object.entries(PermissionFlags).map(([key, value]) => (
                        <div key={key} className="flex items-center space-x-2">
                          <Checkbox
                            id={`permission-${key}`}
                            checked={selectedPermissions.includes(value)}
                            onCheckedChange={() => togglePermission(value)}
                          />
                          <Label htmlFor={`permission-${key}`}>
                            {PERMISSION_LABELS[key as keyof typeof PermissionFlags]}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => createRoleMutation.mutate()}
                      disabled={!newRoleName.trim() || createRoleMutation.isPending}
                    >
                      Create
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsCreatingRole(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          <TabsContent value="permissions" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Channel Permissions</h3>
              {/* Channel permissions UI will be added here */}
            </div>
          </TabsContent>
          <TabsContent value="members" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Members</h3>
              {members.map((member) => (
                <div
                  key={member.id}
                  className="flex items-center justify-between p-4 border rounded-lg"
                >
                  <div>
                    <p className="font-medium">{member.displayName || member.username}</p>
                    <p className="text-sm text-muted-foreground">@{member.username}</p>
                  </div>
                  <Select
                    onValueChange={(roleId) => {
                      assignRoleMutation.mutate({
                        userId: member.id,
                        roleId: parseInt(roleId),
                      });
                    }}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      {roles.map((role) => (
                        <SelectItem key={role.id} value={role.id.toString()}>
                          {role.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          </TabsContent>
          <TabsContent value="invite" className="space-y-4">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Invite People</h3>
              <p className="text-sm text-muted-foreground">
                Generate an invite link to share with others
              </p>
              <Button
                onClick={() => generateInviteMutation.mutate()}
                disabled={generateInviteMutation.isPending}
                className="w-full"
              >
                <Copy className="h-4 w-4 mr-2" />
                Generate Invite Link
              </Button>
            </div>
          </TabsContent>
          {server?.ownerId !== undefined && server?.ownerId === user?.id && (
            <TabsContent value="danger" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-destructive">Danger Zone</h3>
                <div className="border border-destructive rounded-lg p-4">
                  <h4 className="font-medium mb-2">Delete Server</h4>
                  <p className="text-sm text-muted-foreground mb-4">
                    Permanently delete this server and all of its data. This action cannot be undone.
                  </p>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" className="w-full">
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Server
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone. This will permanently delete the server
                          and remove all data associated with it.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          onClick={async () => {
                            try {
                              await apiRequest(
                                "DELETE",
                                `/api/servers/${serverId}`
                              );
                              queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
                              toast({
                                title: "Server deleted",
                                description: "The server has been permanently deleted",
                              });
                              setIsOpen(false);
                              window.location.href = "/";
                            } catch (error) {
                              toast({
                                title: "Failed to delete server",
                                description: error instanceof Error ? error.message : "An error occurred",
                                variant: "destructive",
                              });
                            }
                          }}
                        >
                          Delete Server
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}