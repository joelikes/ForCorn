import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { UserPlus, Loader2, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, FriendRequest } from "@shared/schema";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { addDays } from "date-fns";
import { UserProfileDialog } from "./user-profile-dialog";

type AddFriendDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
];

export function AddFriendDialog({ open, onOpenChange }: AddFriendDialogProps) {
  const [username, setUsername] = useState("");
  const [message, setMessage] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState<number | null>(null);
  const { toast } = useToast();

  // Query to get sent friend requests
  const { data: sentRequests = [] } = useQuery<FriendRequest[]>({
    queryKey: ["/api/friend-requests/sent"],
    enabled: open,
  });

  // Query to get current friends
  const { data: friends = [] } = useQuery<User[]>({
    queryKey: ["/api/friends"],
    enabled: open,
  });

  // Query to search users
  const { data: searchResults = [], refetch: searchUsers } = useQuery<User[]>({
    queryKey: ["/api/users/search", username],
    queryFn: async () => {
      const res = await fetch(`/api/users/search?username=${encodeURIComponent(username)}`);
      if (!res.ok) {
        throw new Error("Failed to search users");
      }
      return res.json();
    },
    enabled: false,
  });

  const sendRequestMutation = useMutation({
    mutationFn: async (receiverId: number) => {
      const expiresAt = addDays(new Date(), 7);
      const res = await apiRequest("POST", "/api/friend-requests", {
        receiverId,
        message: message.trim(),
        expiresAt: expiresAt.toISOString(),
      });
      if (!res.ok) {
        const error = await res.text();
        throw new Error(error);
      }
      return res.json();
    },
    onSuccess: (_, receiverId) => {
      // Invalidate all related queries
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/sent"] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${receiverId}`] });

      const receiver = searchResults.find(user => user.id === receiverId);
      toast({
        title: "Friend request sent",
        description: `Friend request sent to ${receiver?.displayName || receiver?.username}. It will expire in 7 days.`,
      });
      setMessage("");
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send friend request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSearch = async () => {
    if (!username.trim()) {
      toast({
        title: "Invalid username",
        description: "Please enter a username to search",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    try {
      await searchUsers();
    } catch (error) {
      toast({
        title: "Search failed",
        description: error instanceof Error ? error.message : "Failed to search users",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const isPendingRequest = (userId: number) => {
    return sentRequests.some(request => request.receiverId === userId);
  };

  const isFriend = (userId: number) => {
    return friends.some(friend => friend.id === userId);
  };

  const handleViewProfile = (userId: number) => {
    setShowUserProfile(userId);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Add Friend
            </DialogTitle>
            <DialogDescription>
              Search for users by their username to send them a friend request
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <div className="flex gap-2">
                <Input
                  id="username"
                  placeholder="Enter username..."
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handleSearch();
                    }
                  }}
                />
                <Button
                  onClick={handleSearch}
                  disabled={!username.trim() || isSearching}
                >
                  {isSearching ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Search className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {searchResults.length > 0 && (
              <div className="space-y-2">
                <Label>Search Results</Label>
                <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                  {searchResults.map((user) => {
                    const isPending = isPendingRequest(user.id);
                    const isAlreadyFriend = isFriend(user.id);
                    const request = sentRequests.find(req => req.receiverId === user.id);
                    const isExpired = request && new Date(request.expiresAt) < new Date();

                    return (
                      <div
                        key={user.id}
                        className="space-y-4 p-4 border rounded-lg"
                      >
                        <div className="flex items-center justify-between">
                          <div 
                            className="flex items-center gap-3 cursor-pointer hover:opacity-80"
                            onClick={() => handleViewProfile(user.id)}
                          >
                            <Avatar className="h-10 w-10">
                              <AvatarImage
                                src={user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length]}
                                alt={user.username}
                              />
                            </Avatar>
                            <div>
                              <p className="font-medium">
                                {user.displayName || user.username}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                @{user.username}
                              </p>
                            </div>
                          </div>
                        </div>

                        {!isPending && !isAlreadyFriend && (
                          <div className="space-y-2">
                            <Label htmlFor={`message-${user.id}`}>Add a message</Label>
                            <Textarea
                              id={`message-${user.id}`}
                              placeholder="Write a message to introduce yourself..."
                              value={message}
                              onChange={(e) => setMessage(e.target.value)}
                              className="resize-none"
                              rows={3}
                            />
                          </div>
                        )}

                        <div className="flex justify-between items-center">
                          {isExpired && (
                            <p className="text-sm text-destructive">
                              Previous request expired
                            </p>
                          )}
                          <div className="flex-1" />
                          {isAlreadyFriend ? (
                            <Button
                              size="sm"
                              variant="secondary"
                              disabled
                            >
                              Already Friends
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant={isPending && !isExpired ? "secondary" : "default"}
                              onClick={() => sendRequestMutation.mutate(user.id)}
                              disabled={(isPending && !isExpired) || sendRequestMutation.isPending}
                            >
                              {sendRequestMutation.isPending && sendRequestMutation.variables === user.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : isPending && !isExpired ? (
                                "Request Sent"
                              ) : (
                                <>
                                  <UserPlus className="h-4 w-4 mr-2" />
                                  {isExpired ? "Send New Request" : "Add Friend"}
                                </>
                              )}
                            </Button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {showUserProfile !== null && (
        <UserProfileDialog
          userId={showUserProfile}
          isOpen={true}
          onClose={() => setShowUserProfile(null)}
        />
      )}
    </>
  );
}