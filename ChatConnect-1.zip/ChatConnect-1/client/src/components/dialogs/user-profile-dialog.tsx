import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useQuery, useMutation } from "@tanstack/react-query";
import type { User, Friend } from "@shared/schema";
import { MessageSquare, Server, Lock, Loader2, PhoneCall, Award, Activity, Users, UserPlus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { CallDialog } from "./call-dialog";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { addDays } from "date-fns";
import type { FriendRequest } from "@shared/schema";


interface UserProfileDialogProps {
  userId: number;
  isOpen: boolean;
  onClose: () => void;
}

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

const BADGE_NAMES = {
  vip: "ForCorn VIP",
  super_vip: "Super VIP",
  moderator: "Moderator",
  early_supporter: "Early Supporter",
};

const isPendingRequest = (userId: number): boolean => {
  const sentRequests = queryClient.getQueryData<FriendRequest[]>(
    ["/api/friend-requests/sent"]
  );
  return sentRequests?.some((request) => request.receiverId === userId && request.status === "pending");
};


export function UserProfileDialog({ userId, isOpen, onClose }: UserProfileDialogProps) {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const { setSelectedChannel } = useSelectedChannel();
  const [isCallDialogOpen, setIsCallDialogOpen] = useState(false);

  const { data: user, isLoading } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: isOpen,
  });

  const { data: currentUser } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  const { data: friends = [] } = useQuery<Friend[]>({
    queryKey: ["/api/friends"],
    enabled: isOpen && !!currentUser,
  });

  const { data: mutualServers = [] } = useQuery<{ id: number; name: string; }[]>({
    queryKey: [`/api/users/${userId}/mutual-servers`],
    enabled: isOpen,
  });

  const { data: userFriends = [] } = useQuery<User[]>({
    queryKey: [`/api/users/${userId}/friends`],
    enabled: isOpen,
  });

  const areFriends = friends.some(
    (friend) =>
      (friend.user1Id === currentUser?.id && friend.user2Id === userId) ||
      (friend.user2Id === currentUser?.id && friend.user1Id === userId)
  );

  const hasSharedServer = mutualServers?.length > 0;
  const canMessage = areFriends || (hasSharedServer && user?.allowNonFriendMessages);
  const isBlocked = user?.blockedUsers?.includes(currentUser?.id ?? 0);

  const handleMessageClick = () => {
    if (!canMessage) {
      toast({
        title: "Cannot send message",
        description: areFriends
          ? "You've been blocked by this user"
          : "This user only accepts messages from friends",
        variant: "destructive",
      });
      return;
    }

    onClose();
    setSelectedChannel(null);
    setLocation(`/?userId=${userId}`);
  };

  const handleCallClick = () => {
    if (!canMessage) {
      toast({
        title: "Cannot start call",
        description: areFriends
          ? "You've been blocked by this user"
          : "You can only call friends or server members",
        variant: "destructive",
      });
      return;
    }

    setIsCallDialogOpen(true);
  };

  const renderBadges = (badges: string[] | null | undefined) => {
    if (!badges?.length) return null;
    return (
      <div className="space-y-2">
        <h4 className="text-sm font-medium flex items-center gap-2">
          <Award className="h-4 w-4" />
          Badges
        </h4>
        <div className="flex flex-wrap gap-2">
          {badges.map((badge) => (
            <div key={badge} className="px-2 py-1 bg-secondary rounded-md text-xs">
              {BADGE_NAMES[badge as keyof typeof BADGE_NAMES] || badge}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderServerMemberships = () => {
    if (!mutualServers?.length) return null;
    return (
      <div className="space-y-2">
        <h4 className="text-sm font-medium flex items-center gap-2">
          <Server className="h-4 w-4" />
          Mutual Servers
        </h4>
        <div className="space-y-1">
          {mutualServers.map((server) => (
            <div key={server.id} className="text-sm text-muted-foreground">
              {server.name}
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderFriendsList = () => {
    if (!userFriends?.length) return null;
    return (
      <div className="space-y-2">
        <h4 className="text-sm font-medium flex items-center gap-2">
          <Users className="h-4 w-4" />
          Friends
        </h4>
        <ScrollArea className="h-[100px]">
          <div className="space-y-2">
            {userFriends.map((friend) => (
              <div key={friend.id} className="flex items-center gap-2">
                <Avatar className="h-6 w-6">
                  <AvatarImage
                    src={friend.avatar || DEFAULT_USER_AVATARS[friend.id % DEFAULT_USER_AVATARS.length]}
                    alt={friend.username}
                  />
                </Avatar>
                <span className="text-sm">{friend.displayName || friend.username}</span>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    );
  };

  const sendFriendRequestMutation = useMutation({
    mutationFn: async () => {
      const expiresAt = addDays(new Date(), 7);
      const response = await apiRequest("POST", "/api/friend-requests", {
        receiverId: userId,
        expiresAt: expiresAt.toISOString(),
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to send friend request");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.setQueryData<FriendRequest[]>(
        ["/api/friend-requests/sent"],
        (oldRequests = []) => {
          const newRequest = {
            id: Date.now(),
            senderId: currentUser?.id || 0,
            receiverId: userId,
            message: "",
            status: "pending",
            expiresAt: addDays(new Date(), 7).toISOString(),
            createdAt: new Date().toISOString(),
          };
          return [...oldRequests, newRequest];
        }
      );
      toast({
        title: "Friend request sent",
        description: `Friend request sent to ${user?.displayName || user?.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send friend request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[425px] max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>User Profile</DialogTitle>
          </DialogHeader>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : user ? (
            <ScrollArea className="flex-1">
              <div className="space-y-6 p-1 pr-4">
                <div className="flex items-start gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage
                      src={user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length]}
                      alt={user.username}
                    />
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold truncate">
                      {user.displayName || user.username}
                    </h3>
                    <p className="text-sm text-muted-foreground truncate">@{user.username}</p>
                    {user.activityStatus && (
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                        <Activity className="h-3 w-3" />
                        {user.activityStatus}
                      </p>
                    )}
                  </div>
                  {userId !== currentUser?.id && (
                    <div className="flex flex-wrap gap-2">
                      {!areFriends && isPendingRequest(userId) ? (
                        <Button
                          variant="secondary"
                          size="sm"
                          disabled
                          className="flex items-center gap-2"
                        >
                          Pending
                        </Button>
                      ) : !areFriends && (
                        <Button
                          variant="secondary"
                          size="sm"
                          className="flex items-center gap-2"
                          onClick={() => {
                            if (!sendFriendRequestMutation.isPending) {
                              sendFriendRequestMutation.mutate();
                            }
                          }}
                          disabled={sendFriendRequestMutation.isPending}
                        >
                          {sendFriendRequestMutation.isPending ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <>
                              <UserPlus className="h-4 w-4" />
                              Add Friend
                            </>
                          )}
                        </Button>
                      )}
                      <Button
                        variant={canMessage ? "default" : "secondary"}
                        size="sm"
                        className="flex items-center gap-2"
                        onClick={handleMessageClick}
                        disabled={!canMessage}
                      >
                        <MessageSquare className="h-4 w-4" />
                        Message
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        className="flex items-center gap-2"
                        onClick={handleCallClick}
                        disabled={!canMessage}
                      >
                        <PhoneCall className="h-4 w-4" />
                        Call
                      </Button>
                    </div>
                  )}
                </div>

                <Card className="p-4 space-y-4">
                  {user.aboutMe && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">About Me</h4>
                      <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                        {user.aboutMe}
                      </p>
                    </div>
                  )}

                  {user.badges && user.badges.length > 0 && (
                    <>
                      <Separator />
                      {renderBadges(user.badges)}
                    </>
                  )}

                  {mutualServers && mutualServers.length > 0 && (
                    <>
                      <Separator />
                      {renderServerMemberships()}
                    </>
                  )}

                  {userFriends && userFriends.length > 0 && (
                    <>
                      <Separator />
                      {renderFriendsList()}
                    </>
                  )}
                </Card>

                <div className="text-xs text-muted-foreground">
                  Joined {format(new Date(user.joinedAt), "MMMM d, yyyy")}
                </div>
              </div>
            </ScrollArea>
          ) : (
            <div className="py-8 text-center text-muted-foreground">
              User not found
            </div>
          )}
        </DialogContent>
      </Dialog>

      <CallDialog
        type="voice"
        recipientName={user?.displayName || user?.username}
        recipientId={userId}
        isOpen={isCallDialogOpen}
        onClose={() => setIsCallDialogOpen(false)}
      />
    </>
  );
}