import { useState } from "react";
import { Loader2, AlertCircle, UserPlus } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, FriendRequest } from "@shared/schema";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import { UserProfileDialog } from "./user-profile-dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { addDays } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { ScrollArea } from "@/components/ui/scroll-area";

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

interface UserSearchDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserSearchDialog({ isOpen, onClose }: UserSearchDialogProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();
  const { user: currentUser } = useAuth();

  const {
    data: searchResults = [],
    isLoading,
    refetch
  } = useQuery<User[]>({
    queryKey: ["/api/users/search", searchQuery],
    queryFn: async () => {
      try {
        const response = await apiRequest("GET", `/api/users/search?q=${encodeURIComponent(searchQuery)}`);
        if (!response.ok) {
          throw new Error(await response.text() || "Failed to search users");
        }
        return response.json();
      } catch (error) {
        console.error("Search error:", error);
        throw error;
      }
    },
    enabled: isOpen && searchQuery.length > 0,
    retry: false,
  });

  const { data: sentRequests = [] } = useQuery<FriendRequest[]>({
    queryKey: ["/api/friend-requests/sent"],
    enabled: isOpen,
  });

  const { data: friends = [] } = useQuery<User[]>({
    queryKey: ["/api/friends"],
    enabled: isOpen,
  });

  const sendFriendRequestMutation = useMutation({
    mutationFn: async (receiverId: number) => {
      const expiresAt = addDays(new Date(), 7); 
      const response = await apiRequest("POST", "/api/friend-requests", {
        receiverId,
        expiresAt: expiresAt.toISOString(),
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || "Failed to send friend request");
      }
      return response.json();
    },
    onSuccess: (_, receiverId) => {
      queryClient.setQueryData<FriendRequest[]>(
        ["/api/friend-requests/sent"],
        (oldRequests = []) => {
          const newRequest = {
            id: Date.now(), 
            senderId: currentUser?.id || 0,
            receiverId,
            message: "",
            status: "pending",
            expiresAt: addDays(new Date(), 7).toISOString(),
            createdAt: new Date().toISOString(),
          };
          return [...oldRequests, newRequest];
        }
      );

      const user = searchResults.find(u => u.id === receiverId);
      toast({
        title: "Friend request sent",
        description: `Friend request sent to ${user?.displayName || user?.username}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send friend request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleViewProfile = (userId: number) => {
    setSelectedUserId(userId);
  };

  const isPendingRequest = (userId: number) => {
    return sentRequests.some(request => request.receiverId === userId);
  };

  const isFriend = (userId: number) => {
    return friends.some(friend => friend.id === userId);
  };

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    if (value.trim()) {
      refetch();
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="sm:max-w-[425px] max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Search Users</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 flex-1 flex flex-col min-h-0">
            <div className="relative">
              <Input
                placeholder="Search by username..."
                value={searchQuery}
                onChange={handleSearchInput}
                className="w-full"
                autoFocus
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <ScrollArea className="flex-1">
              <div className="space-y-2 pr-4">
                {isLoading ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <div key={i} className="flex items-center gap-4 p-2">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-[200px]" />
                        <Skeleton className="h-4 w-[150px]" />
                      </div>
                    </div>
                  ))
                ) : searchResults.length > 0 ? (
                  searchResults.map((user) => {
                    const isPending = isPendingRequest(user.id);
                    const isCurrentUserFriend = isFriend(user.id);

                    return (
                      <div
                        key={user.id}
                        className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div 
                          className="flex items-center gap-3 cursor-pointer hover:opacity-80"
                          onClick={() => handleViewProfile(user.id)}
                        >
                          <Avatar className="h-12 w-12">
                            <AvatarImage
                              src={user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length]}
                              alt={user.username}
                            />
                          </Avatar>
                          <div>
                            <p className="font-medium">
                              {user.displayName || user.username}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              @{user.username}
                            </p>
                          </div>
                        </div>

                        {user.id !== currentUser?.id && (
                          <>
                            {isCurrentUserFriend ? null : isPending ? (
                              <Button
                                variant="secondary"
                                size="sm"
                                disabled
                                className="h-8"
                              >
                                Pending
                              </Button>
                            ) : (
                              <Button
                                variant="default"
                                size="sm"
                                onClick={() => {
                                  if (!sendFriendRequestMutation.isPending) {
                                    sendFriendRequestMutation.mutate(user.id);
                                  }
                                }}
                                disabled={sendFriendRequestMutation.isPending}
                                className="h-8"
                              >
                                {sendFriendRequestMutation.isPending ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <>
                                    <UserPlus className="h-4 w-4 mr-1.5" />
                                    Add
                                  </>
                                )}
                              </Button>
                            )}
                          </>
                        )}
                      </div>
                    );
                  })
                ) : searchQuery.length > 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No users found
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground py-8">
                    Start typing to search for users
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>

      {selectedUserId !== null && (
        <UserProfileDialog
          userId={selectedUserId}
          isOpen={true}
          onClose={() => setSelectedUserId(null)}
        />
      )}
    </>
  );
}