import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";

const PREDEFINED_STATUSES = [
  { label: "Online", value: "online" },
  { label: "Away", value: "away" },
  { label: "Do Not Disturb", value: "dnd" },
  { label: "Busy", value: "busy" },
  { label: "Working", value: "working" },
  { label: "Available", value: "available" },
];

interface UserStatusDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function UserStatusDialog({ isOpen, onClose }: UserStatusDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [status, setStatus] = useState(user?.status || "online");
  const [customStatus, setCustomStatus] = useState(user?.customStatus || "");

  const updateStatusMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("PATCH", `/api/users/${user?.id}/status`, {
        status,
        customStatus: customStatus.trim(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Status updated",
        description: "Your status has been updated successfully.",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update status",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateStatusMutation.isPending) {
      updateStatusMutation.mutate();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update Status</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            {PREDEFINED_STATUSES.map((s) => (
              <Button
                key={s.value}
                type="button"
                variant={status === s.value ? "default" : "outline"}
                onClick={() => setStatus(s.value)}
              >
                {s.label}
              </Button>
            ))}
          </div>
          <div className="space-y-2">
            <Input
              placeholder="What's on your mind?"
              value={customStatus}
              onChange={(e) => setCustomStatus(e.target.value)}
              maxLength={100}
            />
            <p className="text-xs text-muted-foreground text-right">
              {customStatus.length}/100
            </p>
          </div>
          <div className="flex justify-end gap-2">
            <Button
              type="submit"
              disabled={updateStatusMutation.isPending}
            >
              Save Changes
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
