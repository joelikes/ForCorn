import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Switch } from "@/components/ui/switch";

interface CreateChannelDialogProps {
  serverId: number;
}

export function CreateChannelDialog({ serverId }: CreateChannelDialogProps) {
  const [open, setOpen] = useState(false);
  const [channelName, setChannelName] = useState("");
  const [isVoice, setIsVoice] = useState(false);
  const { toast } = useToast();

  const createChannelMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/servers/${serverId}/channels`, {
        name: channelName,
        isVoice,
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to create channel");
      }
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/servers/${serverId}/channels`] 
      });
      toast({
        title: "Channel created",
        description: "Your new channel has been created successfully",
      });
      setOpen(false);
      setChannelName("");
      setIsVoice(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create channel",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (channelName.trim() && !createChannelMutation.isPending) {
      createChannelMutation.mutate();
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="w-full justify-start px-2"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Channel
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a Channel</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="channelName">Channel Name</Label>
            <Input
              id="channelName"
              value={channelName}
              onChange={(e) => setChannelName(e.target.value)}
              placeholder="Enter channel name..."
            />
          </div>
          <div className="flex items-center space-x-2">
            <Switch
              id="isVoice"
              checked={isVoice}
              onCheckedChange={setIsVoice}
            />
            <Label htmlFor="isVoice">Voice Channel</Label>
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={!channelName.trim() || createChannelMutation.isPending}
          >
            Create Channel
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}