import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, UpdateUserProfile } from "@shared/schema";
import {
  Upload,
  Lock,
  Bell,
  Paintbrush,
  Users,
  CreditCard,
  HelpCircle,
  LogOut,
  UserCog,
  Mail,
  Phone,
  Key,
  Link as LinkIcon,
  Shield,
  Eye,
  UserX,
  Activity,
  MessageSquare,
  Languages,
  Filter,
  DollarSign,
  History,
  Gift,
  BookOpen,
  Bug,
  HeadphonesIcon,
  Trash2,
} from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

interface SettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsDialog({ isOpen, onClose }: SettingsDialogProps) {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [displayName, setDisplayName] = useState(user?.displayName || "");
  const [aboutMe, setAboutMe] = useState(user?.aboutMe || "");
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const stored = localStorage.getItem("theme");
    if (stored) return stored === "dark";
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });
  const [messagePrivacy, setMessagePrivacy] = useState("friends");
  const [profileVisibility, setProfileVisibility] = useState("public");
  const [activityStatus, setActivityStatus] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [fontSize, setFontSize] = useState("medium");
  const [contentFilter, setContentFilter] = useState("moderate");
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle("dark", isDarkMode);
    localStorage.setItem("theme", isDarkMode ? "dark" : "light");
  }, [isDarkMode]);

  const updateProfileMutation = useMutation({
    mutationFn: async (data: UpdateUserProfile) => {
      const res = await apiRequest("PATCH", `/api/users/${user?.id}`, data);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to update settings");
      }
      return res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData(["/api/user"], updatedUser);
      toast({
        title: "Settings updated",
        description: "Your profile has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update settings",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!updateProfileMutation.isPending) {
      const updateData: UpdateUserProfile = {
        displayName: displayName.trim() || null,
        aboutMe: aboutMe.trim() || null,
      };
      updateProfileMutation.mutate(updateData);
    }
  };

  const handleLogoutAllDevices = async () => {
    // Implementation would go here
    toast({
      title: "Logged out",
      description: "You have been logged out from all devices",
    });
  };

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl h-[80vh]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="account" className="h-full">
          <div className="flex h-full">
            <TabsList className="flex flex-col h-full space-y-1 rounded-none border-r pr-6 pb-12">
              <TabsTrigger value="account" className="justify-start gap-2">
                <UserCog className="h-4 w-4" />
                Account
              </TabsTrigger>
              <TabsTrigger value="privacy" className="justify-start gap-2">
                <Lock className="h-4 w-4" />
                Privacy & Security
              </TabsTrigger>
              <TabsTrigger value="notifications" className="justify-start gap-2">
                <Bell className="h-4 w-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="appearance" className="justify-start gap-2">
                <Paintbrush className="h-4 w-4" />
                Appearance
              </TabsTrigger>
              <TabsTrigger value="community" className="justify-start gap-2">
                <Users className="h-4 w-4" />
                Community
              </TabsTrigger>
              <TabsTrigger value="subscription" className="justify-start gap-2">
                <CreditCard className="h-4 w-4" />
                Subscription
              </TabsTrigger>
              <TabsTrigger value="help" className="justify-start gap-2">
                <HelpCircle className="h-4 w-4" />
                Help & Support
              </TabsTrigger>
              <TabsTrigger value="logout" className="justify-start gap-2">
                <LogOut className="h-4 w-4" />
                Logout
              </TabsTrigger>
            </TabsList>

            <div className="flex-1 pl-6 pr-2 overflow-y-auto">
              <TabsContent value="account" className="h-full">
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-medium">Profile Information</h3>
                    <form onSubmit={handleProfileSubmit} className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="displayName">Display Name</Label>
                        <Input
                          id="displayName"
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                          placeholder="Enter display name..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="aboutMe">About Me</Label>
                        <Textarea
                          id="aboutMe"
                          value={aboutMe}
                          onChange={(e) => setAboutMe(e.target.value)}
                          placeholder="Tell us about yourself..."
                          className="h-32"
                        />
                      </div>
                      <Button type="submit" disabled={updateProfileMutation.isPending}>
                        Save Profile
                      </Button>
                    </form>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium">Contact Information</h3>
                    <div className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label htmlFor="email">Email Address</Label>
                        <Input type="email" id="email" placeholder="Enter email..." />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input type="tel" id="phone" placeholder="Enter phone number..." />
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium">Security</h3>
                    <div className="space-y-4 mt-4">
                      <Button variant="outline" className="w-full justify-start">
                        <Key className="h-4 w-4 mr-2" />
                        Change Password
                      </Button>
                      <Button variant="outline" className="w-full justify-start">
                        <Shield className="h-4 w-4 mr-2" />
                        Enable Two-Factor Authentication
                      </Button>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-medium">Connected Accounts</h3>
                    <div className="space-y-4 mt-4">
                      <Button variant="outline" className="w-full justify-start">
                        <LinkIcon className="h-4 w-4 mr-2" />
                        Link External Accounts
                      </Button>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="privacy" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Privacy Settings</h3>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Who can message me</Label>
                      <Select value={messagePrivacy} onValueChange={setMessagePrivacy}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="everyone">Everyone</SelectItem>
                          <SelectItem value="friends">Friends Only</SelectItem>
                          <SelectItem value="none">No One</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Profile Visibility</Label>
                      <Select value={profileVisibility} onValueChange={setProfileVisibility}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="public">Public</SelectItem>
                          <SelectItem value="friends">Friends Only</SelectItem>
                          <SelectItem value="private">Private</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Activity Status</Label>
                        <p className="text-sm text-muted-foreground">
                          Show when you're online
                        </p>
                      </div>
                      <Switch
                        checked={activityStatus}
                        onCheckedChange={setActivityStatus}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium">Blocked Users</h3>
                  <div className="mt-4">
                    <Button variant="outline" className="w-full justify-start">
                      <UserX className="h-4 w-4 mr-2" />
                      Manage Blocked Users
                    </Button>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="notifications" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Notification Settings</h3>
                  <div className="space-y-4 mt-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Push Notifications</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive notifications for messages and mentions
                        </p>
                      </div>
                      <Switch
                        checked={pushNotifications}
                        onCheckedChange={setPushNotifications}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Email Notifications</Label>
                        <p className="text-sm text-muted-foreground">
                          Receive email alerts for important updates
                        </p>
                      </div>
                      <Switch
                        checked={emailNotifications}
                        onCheckedChange={setEmailNotifications}
                      />
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="appearance" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Theme Settings</h3>
                  <div className="space-y-4 mt-4">
                    <div className="flex items-center justify-between">
                      <Label>Theme</Label>
                      <Button
                        variant="outline"
                        onClick={() => setIsDarkMode(!isDarkMode)}
                        className="w-24"
                      >
                        {isDarkMode ? "Light" : "Dark"}
                      </Button>
                    </div>

                    <div className="space-y-2">
                      <Label>Font Size</Label>
                      <Select value={fontSize} onValueChange={setFontSize}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">Small</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="large">Large</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="community" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Content Settings</h3>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Content Filter</Label>
                      <Select value={contentFilter} onValueChange={setContentFilter}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="strict">Strict</SelectItem>
                          <SelectItem value="moderate">Moderate</SelectItem>
                          <SelectItem value="off">Off</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label>Language</Label>
                      <Select value={language} onValueChange={setLanguage}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Spanish</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                          <SelectItem value="de">German</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="subscription" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Subscription Management</h3>
                  <div className="space-y-4 mt-4">
                    <Button variant="outline" className="w-full justify-start">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Manage Subscription
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <History className="h-4 w-4 mr-2" />
                      View Payment History
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Gift className="h-4 w-4 mr-2" />
                      Set Up Donations
                    </Button>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="help" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Help & Support</h3>
                  <div className="space-y-4 mt-4">
                    <Button variant="outline" className="w-full justify-start">
                      <BookOpen className="h-4 w-4 mr-2" />
                      View FAQ & Tutorials
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Bug className="h-4 w-4 mr-2" />
                      Report a Bug
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <HeadphonesIcon className="h-4 w-4 mr-2" />
                      Contact Support
                    </Button>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="logout" className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium">Account Actions</h3>
                  <div className="space-y-4 mt-4">
                    <Button
                      variant="outline"
                      className="w-full justify-start"
                      onClick={handleLogoutAllDevices}
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      Log Out from All Devices
                    </Button>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="destructive"
                          className="w-full justify-start"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Account
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Account</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete your
                            account and remove your data from our servers.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction className="bg-destructive text-destructive-foreground">
                            Delete Account
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </TabsContent>
            </div>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}