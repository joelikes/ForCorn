import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

interface JoinServerDialogProps {
  inviteCode?: string;
  isOpen: boolean;
  onClose: () => void;
}

export function JoinServerDialog({ inviteCode: initialInviteCode, isOpen, onClose }: JoinServerDialogProps) {
  const { toast } = useToast();
  const [inviteCode, setInviteCode] = useState(initialInviteCode || "");

  // Reset invite code when dialog opens
  useEffect(() => {
    if (isOpen) {
      setInviteCode(initialInviteCode || "");
    }
  }, [isOpen, initialInviteCode]);

  // Extract invite code from pasted invite link
  const handleInvitePaste = (text: string) => {
    const match = text.match(/\/invite\/([a-zA-Z0-9]+)/);
    if (match) {
      setInviteCode(match[1]);
    } else {
      setInviteCode(text.trim());
    }
  };

  // Query server details from invite code
  const { data: serverDetails, isLoading: isLoadingDetails } = useQuery({
    queryKey: [`/api/invites/${inviteCode}/details`],
    enabled: isOpen && !!inviteCode,
  });

  const joinServerMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/invites/${inviteCode}/join`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      toast({
        title: "Server joined",
        description: "You have successfully joined the server",
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to join server",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Join Server</DialogTitle>
          <DialogDescription>
            Enter an invite link or code to join a server
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Input
              placeholder="Paste an invite link or code"
              value={inviteCode}
              onChange={(e) => handleInvitePaste(e.target.value)}
            />
          </div>

          {isLoadingDetails && inviteCode && (
            <div className="flex justify-center py-4">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          )}

          {serverDetails && (
            <div className="space-y-4">
              <div className="p-4 rounded-lg bg-muted">
                <h3 className="font-semibold mb-2">You've been invited to join:</h3>
                <p className="text-xl font-bold">{serverDetails.name}</p>
                {serverDetails.memberCount && (
                  <p className="text-sm text-muted-foreground">
                    {serverDetails.memberCount} members
                  </p>
                )}
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button 
                  onClick={() => joinServerMutation.mutate()}
                  disabled={joinServerMutation.isPending}
                >
                  Accept Invite
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}