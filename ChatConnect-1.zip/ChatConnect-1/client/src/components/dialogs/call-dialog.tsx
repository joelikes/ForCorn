import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Phone, Video, MicOff, VideoOff, X, Users } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import SimplePeer from "simple-peer";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";

interface CallDialogProps {
  type?: "voice" | "video";
  recipientName?: string;
  recipientId?: number;
  channelId?: number;
  isOpen: boolean;
  onClose: () => void;
  isIncoming?: boolean;
}

interface Participant {
  id: number;
  stream?: MediaStream;
  peer?: SimplePeer.Instance;
  username?: string;
}

export function CallDialog({
  type = "voice",
  recipientName,
  recipientId,
  channelId,
  isOpen,
  onClose,
  isIncoming = false
}: CallDialogProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [participants, setParticipants] = useState<Map<number, Participant>>(new Map());
  const [isCallActive, setIsCallActive] = useState(false);
  const [ws, setWs] = useState<WebSocket | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: channelMembers = [] } = useQuery<User[]>({
    queryKey: [`/api/channels/${channelId}/members`],
    enabled: !!channelId && isCallActive,
  });

  useEffect(() => {
    if (isOpen && !ws && user) {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsConnection = new WebSocket(`${protocol}//${window.location.host}/webrtc`);

      wsConnection.onopen = () => {
        console.log('WebRTC WebSocket connected');
      };

      wsConnection.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);

          switch (data.type) {
            case 'call_request':
              if (!isCallActive) {
                handleIncomingCall(data);
              }
              break;
            case 'user_joined':
              if (isCallActive) {
                handleUserJoined(data);
              }
              break;
            case 'user_left':
              handleUserLeft(data.userId);
              break;
            case 'signal':
              handleSignal(data);
              break;
          }
        } catch (error) {
          console.error('WebSocket message error:', error);
        }
      };

      setWs(wsConnection);
    }

    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [isOpen, user, isCallActive]);

  const handleIncomingCall = (data: any) => {
    toast({
      title: "Incoming Call",
      description: `${data.from.username} is calling you`,
      action: (
        <div className="flex gap-2">
          <Button size="sm" onClick={() => handleAcceptCall(data)}>
            Accept
          </Button>
          <Button size="sm" variant="destructive" onClick={handleRejectCall}>
            Decline
          </Button>
        </div>
      ),
      duration: 30000,
    });
  };

  const handleUserJoined = async (data: any) => {
    try {
      const newPeer = new SimplePeer({
        initiator: true,
        stream: localStream!,
        trickle: false
      });

      newPeer.on('signal', signalData => {
        if (ws?.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'signal',
            to: data.userId,
            data: signalData
          }));
        }
      });

      newPeer.on('stream', (remoteStream) => {
        setParticipants(prev => {
          const updated = new Map(prev);
          const participant = updated.get(data.userId) || { id: data.userId };
          updated.set(data.userId, { ...participant, stream: remoteStream });
          return updated;
        });
      });

      setParticipants(prev => {
        const updated = new Map(prev);
        updated.set(data.userId, { id: data.userId, peer: newPeer });
        return updated;
      });
    } catch (error) {
      console.error('Error handling user joined:', error);
    }
  };

  const handleUserLeft = (userId: number) => {
    const participant = participants.get(userId);
    if (participant?.peer) {
      participant.peer.destroy();
    }
    setParticipants(prev => {
      const updated = new Map(prev);
      updated.delete(userId);
      return updated;
    });
  };

  const handleSignal = (data: any) => {
    const participant = participants.get(data.from);
    if (participant?.peer) {
      participant.peer.signal(data.signal);
    }
  };

  const handleAcceptCall = async (data: any) => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: type === "video"
      });
      setLocalStream(mediaStream);

      const newPeer = new SimplePeer({
        initiator: false,
        stream: mediaStream,
        trickle: false
      });

      newPeer.on('signal', signalData => {
        if (ws?.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'signal',
            to: data.from.id,
            data: signalData
          }));
        }
      });

      newPeer.on('stream', (remoteStream) => {
        setParticipants(prev => {
          const updated = new Map(prev);
          const participant = updated.get(data.from.id) || { id: data.from.id };
          updated.set(data.from.id, { ...participant, stream: remoteStream });
          return updated;
        });
      });

      setParticipants(prev => {
        const updated = new Map(prev);
        updated.set(data.from.id, { id: data.from.id, peer: newPeer });
        return updated;
      });

      setIsCallActive(true);
    } catch (error) {
      console.error('Failed to accept call:', error);
      toast({
        title: "Call Error",
        description: "Failed to access microphone/camera",
        variant: "destructive",
      });
    }
  };

  const handleRejectCall = () => {
    if (ws?.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({
        type: 'call_rejected',
        to: recipientId
      }));
    }
    onClose();
  };

  const startCall = async () => {
    if (!recipientId && !channelId || !ws || !user) return;

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: type === "video"
      });
      setLocalStream(mediaStream);

      if (videoRef.current && type === "video") {
        videoRef.current.srcObject = mediaStream;
      }

      if (channelId) {
        // Group call in channel
        ws.send(JSON.stringify({
          type: 'join_channel_call',
          channelId,
          userId: user.id
        }));
      } else {
        // Direct call
        ws.send(JSON.stringify({
          type: 'call_request',
          to: recipientId,
          from: user
        }));
      }

      setIsCallActive(true);
    } catch (error) {
      console.error('Failed to start call:', error);
      toast({
        title: "Call Error",
        description: "Failed to access microphone/camera",
        variant: "destructive",
      });
    }
  };

  const handleMuteToggle = () => {
    if (localStream) {
      localStream.getAudioTracks().forEach(track => {
        track.enabled = !isMuted;
      });
      setIsMuted(!isMuted);
    }
  };

  const handleVideoToggle = () => {
    if (localStream) {
      localStream.getVideoTracks().forEach(track => {
        track.enabled = !isVideoOff;
      });
      setIsVideoOff(!isVideoOff);
    }
  };

  const handleEndCall = () => {
    if (localStream) {
      localStream.getTracks().forEach(track => track.stop());
    }
    participants.forEach(participant => {
      if (participant.peer) {
        participant.peer.destroy();
      }
    });
    setParticipants(new Map());
    setLocalStream(null);
    setIsCallActive(false);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isIncoming ? "Incoming Call" : type === "voice" ? "Voice Call" : "Video Call"}
            {recipientName && ` ${isIncoming ? "from" : "with"} ${recipientName}`}
            {channelId && " in channel"}
          </DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center space-y-6 py-4">
          {isCallActive ? (
            <div className="space-y-4 w-full">
              {type === "video" && (
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      playsInline
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                    <span className="absolute bottom-2 left-2 text-xs bg-background/80 px-2 py-1 rounded">
                      You
                    </span>
                  </div>
                  {Array.from(participants.values()).map(participant => (
                    <div key={participant.id} className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                      {participant.stream && (
                        <video
                          autoPlay
                          playsInline
                          className="absolute inset-0 w-full h-full object-cover"
                          srcObject={participant.stream}
                        />
                      )}
                      <span className="absolute bottom-2 left-2 text-xs bg-background/80 px-2 py-1 rounded">
                        {participant.username || `User ${participant.id}`}
                      </span>
                    </div>
                  ))}
                </div>
              )}
              {type === "voice" && (
                <div className="grid grid-cols-2 gap-2">
                  {Array.from(participants.values()).map(participant => (
                    <div key={participant.id} className="flex items-center justify-center p-4 bg-muted rounded-lg">
                      <Users className="h-8 w-8 text-muted-foreground" />
                      <span className="ml-2">{participant.username || `User ${participant.id}`}</span>
                      {participant.stream && (
                        <audio autoPlay playsInline />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <>
              {type === "voice" ? (
                <Phone className="h-16 w-16 text-muted-foreground animate-pulse" />
              ) : (
                <Video className="h-16 w-16 text-muted-foreground animate-pulse" />
              )}
              <p className="text-sm text-muted-foreground">
                {isIncoming
                  ? `Incoming call from ${recipientName}`
                  : channelId
                  ? "Start a call in this channel"
                  : `Ready to call ${recipientName}`}
              </p>
              {!isIncoming && <Button onClick={startCall}>Start Call</Button>}
            </>
          )}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={handleMuteToggle}
            >
              {isMuted ? (
                <MicOff className="h-4 w-4" />
              ) : (
                <Phone className="h-4 w-4" />
              )}
            </Button>
            {type === "video" && (
              <Button
                variant="outline"
                size="icon"
                onClick={handleVideoToggle}
              >
                {isVideoOff ? (
                  <VideoOff className="h-4 w-4" />
                ) : (
                  <Video className="h-4 w-4" />
                )}
              </Button>
            )}
            <Button
              variant="destructive"
              size="icon"
              onClick={handleEndCall}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}