import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { User, FriendRequest } from "@shared/schema";
import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Bell, Check, X, UserCheck, AlertCircle } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";
import React from "react";

type FriendRequestDialogProps = {
  isOpen: boolean;
  onClose: () => void;
};

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function FriendRequestDialog({ isOpen, onClose }: FriendRequestDialogProps) {
  const { toast } = useToast();
  const [error, setError] = React.useState<string | null>(null);

  // Get pending friend requests
  const { data: receivedRequests = [], isLoading: isLoadingRequests } = useQuery<FriendRequest[]>({
    queryKey: ["/api/friend-requests/received"],
    enabled: isOpen,
  });

  // Get user details for the requests
  const { data: users = [], isLoading: isLoadingUsers } = useQuery<User[]>({
    queryKey: ["/api/users"],
    enabled: receivedRequests.length > 0,
  });

  const acceptRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        status: "accepted"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to accept friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      // Invalidate all related queries to refresh the UI state
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/sent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friends"] });
      // Also invalidate the specific user's data to update their profile status
      const request = receivedRequests.find(r => r.id === requestId);
      if (request?.senderId) {
        queryClient.invalidateQueries({ queryKey: [`/api/users/${request.senderId}`] });
      }

      const sender = users.find(u => u.id === request?.senderId);
      toast({
        title: "Friend request accepted",
        description: sender ? `You are now friends with ${sender.displayName || sender.username}!` : "You are now friends!",
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to accept request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const rejectRequestMutation = useMutation({
    mutationFn: async (requestId: number) => {
      const response = await apiRequest("POST", `/api/friend-requests/${requestId}/respond`, {
        status: "rejected"
      });
      if (!response.ok) {
        throw new Error(await response.text() || "Failed to reject friend request");
      }
      return response.json();
    },
    onSuccess: (_, requestId) => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/received"] });
      queryClient.invalidateQueries({ queryKey: ["/api/friend-requests/sent"] });

      const request = receivedRequests.find(r => r.id === requestId);
      if (request?.senderId) {
        queryClient.invalidateQueries({ queryKey: [`/api/users/${request.senderId}`] });
      }

      const sender = users.find(u => u.id === request?.senderId);
      toast({
        title: "Friend request rejected",
        description: sender ? `Rejected request from ${sender.displayName || sender.username}` : undefined,
      });
    },
    onError: (error: Error) => {
      setError(error.message);
      toast({
        title: "Failed to reject request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const isLoading = isLoadingRequests || isLoadingUsers;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Friend Requests
            {receivedRequests.length > 0 && (
              <span className="ml-2 text-sm text-muted-foreground">
                ({receivedRequests.length})
              </span>
            )}
          </DialogTitle>
          <DialogDescription>
            Review and respond to your pending friend requests
          </DialogDescription>
        </DialogHeader>

        <div className="mt-4">
          {error ? (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          ) : isLoading ? (
            <div className="flex items-center justify-center h-[200px]">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : receivedRequests.length > 0 ? (
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-4">
                {receivedRequests.map((request) => {
                  const sender = users.find(u => u.id === request.senderId);
                  if (!sender) return null;

                  const isAccepting = acceptRequestMutation.isPending && acceptRequestMutation.variables === request.id;
                  const isRejecting = rejectRequestMutation.isPending && rejectRequestMutation.variables === request.id;

                  return (
                    <div
                      key={request.id}
                      className="flex flex-col p-4 border rounded-lg bg-background hover:bg-accent/50 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage
                              src={sender.avatar || DEFAULT_USER_AVATARS[sender.id % DEFAULT_USER_AVATARS.length]}
                              alt={sender.username}
                            />
                          </Avatar>
                          <div>
                            <p className="font-medium">
                              {sender.displayName || sender.username}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              @{sender.username}
                            </p>
                          </div>
                        </div>
                      </div>

                      {request.message && (
                        <div className="mt-3 p-3 bg-muted rounded-md">
                          <p className="text-sm whitespace-pre-wrap">{request.message}</p>
                        </div>
                      )}

                      <div className="flex justify-end gap-2 mt-4">
                        <Button
                          size="sm"
                          onClick={() => acceptRequestMutation.mutate(request.id)}
                          disabled={isAccepting || isRejecting}
                          className="relative"
                        >
                          {isAccepting ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <>
                              <Check className="h-4 w-4 mr-2" />
                              Accept
                            </>
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => rejectRequestMutation.mutate(request.id)}
                          disabled={isAccepting || isRejecting}
                          className="relative"
                        >
                          {isRejecting ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <>
                              <X className="h-4 w-4 mr-2" />
                              Reject
                            </>
                          )}
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          ) : (
            <div className="flex flex-col items-center justify-center h-[200px] text-muted-foreground gap-2">
              <UserCheck className="h-8 w-8" />
              <p>No pending friend requests</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}