import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { X } from "lucide-react";
import { UserTag } from "@shared/schema";

interface UserTagsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  serverId: number;
  userId: number;
}

const PREDEFINED_COLORS = [
  "#FF5733", "#33FF57", "#3357FF", "#FF33F5",
  "#33FFF5", "#FFB533", "#FF3333", "#33FF33"
];

export function UserTagsDialog({ isOpen, onClose, serverId, userId }: UserTagsDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newTag, setNewTag] = useState("");
  const [selectedColor, setSelectedColor] = useState(PREDEFINED_COLORS[0]);

  const { data: tags = [] } = useQuery<UserTag[]>({
    queryKey: [`/api/servers/${serverId}/users/${userId}/tags`],
    enabled: isOpen,
  });

  const addTagMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", `/api/servers/${serverId}/users/${userId}/tags`, {
        tag: newTag.trim(),
        color: selectedColor,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/servers/${serverId}/users/${userId}/tags`] 
      });
      setNewTag("");
      toast({
        title: "Tag added",
        description: "The tag has been added successfully.",
      });
    },
  });

  const removeTagMutation = useMutation({
    mutationFn: async (tag: string) => {
      await apiRequest(
        "DELETE",
        `/api/servers/${serverId}/users/${userId}/tags/${encodeURIComponent(tag)}`
      );
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ 
        queryKey: [`/api/servers/${serverId}/users/${userId}/tags`] 
      });
      toast({
        title: "Tag removed",
        description: "The tag has been removed successfully.",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTag.trim() && !addTagMutation.isPending) {
      addTagMutation.mutate();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Manage Tags</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="New tag"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                maxLength={20}
              />
              <Button
                type="submit"
                disabled={!newTag.trim() || addTagMutation.isPending}
              >
                Add
              </Button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {PREDEFINED_COLORS.map((color) => (
                <Button
                  key={color}
                  type="button"
                  variant="outline"
                  className="w-8 h-8 p-0"
                  style={{
                    backgroundColor: color,
                    borderColor: selectedColor === color ? "white" : "transparent",
                    borderWidth: selectedColor === color ? "2px" : "0",
                  }}
                  onClick={() => setSelectedColor(color)}
                />
              ))}
            </div>
          </form>
          <div className="space-y-2">
            {tags.map((tag) => (
              <div
                key={tag.id}
                className="flex items-center justify-between p-2 rounded-md bg-secondary"
              >
                <div
                  className="px-2 py-1 rounded text-sm"
                  style={{ backgroundColor: tag.color }}
                >
                  {tag.tag}
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeTagMutation.mutate(tag.tag)}
                  disabled={removeTagMutation.isPending}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
