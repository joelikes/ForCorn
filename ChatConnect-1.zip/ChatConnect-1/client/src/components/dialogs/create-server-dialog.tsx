import { useState, useRef } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { z } from "zod";
import { useSelectedChannel } from "@/hooks/use-selected-channel";
import { useLocation } from "wouter";

// Define server name validation schema
const serverSchema = z.object({
  name: z.string()
    .min(1, "Server name is required")
    .max(100, "Server name cannot exceed 100 characters")
    .trim(),
  icon: z.string().optional().nullable(),
});

interface CreateServerDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CreateServerDialog({ isOpen, onClose }: CreateServerDialogProps) {
  const [serverName, setServerName] = useState("");
  const [selectedIcon, setSelectedIcon] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { setSelectedServer } = useSelectedChannel();
  const [, setLocation] = useLocation();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File too large",
          description: "Please select an image under 5MB",
          variant: "destructive",
        });
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedIcon(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const createServerMutation = useMutation({
    mutationFn: async () => {
      // Validate server name before sending request
      const validationResult = serverSchema.safeParse({
        name: serverName,
        icon: selectedIcon
      });

      if (!validationResult.success) {
        throw new Error(validationResult.error.errors[0].message);
      }

      const res = await apiRequest("POST", "/api/servers", {
        name: serverName.trim(),
        icon: selectedIcon,
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || "Failed to create server");
      }

      return await res.json();
    },
    onSuccess: (server) => {
      // Invalidate both the servers list query and the specific server query
      queryClient.invalidateQueries({ queryKey: ["/api/servers"] });
      setSelectedServer(server.id);
      setLocation("/servers"); // Navigate to servers page
      toast({
        title: "Server created",
        description: "Your new server has been created successfully",
      });
      onClose();
      setServerName("");
      setSelectedIcon(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to create server",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!createServerMutation.isPending) {
      createServerMutation.mutate();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Create a Server</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="serverName">Server Name</Label>
            <Input
              id="serverName"
              value={serverName}
              onChange={(e) => setServerName(e.target.value)}
              placeholder="Enter server name..."
            />
          </div>
          <div className="space-y-2">
            <Label>Server Icon</Label>
            <div className="flex flex-col items-center gap-4">
              {selectedIcon ? (
                <div className="relative w-32 h-32">
                  <img
                    src={selectedIcon}
                    alt="Server icon preview"
                    className="w-full h-full object-cover rounded-md"
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    className="absolute bottom-2 right-2"
                    onClick={() => setSelectedIcon(null)}
                  >
                    Change
                  </Button>
                </div>
              ) : (
                <Button
                  type="button"
                  variant="outline"
                  className="w-32 h-32 flex flex-col gap-2"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="h-8 w-8" />
                  <span className="text-sm">Upload Image</span>
                </Button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleFileChange}
              />
              <p className="text-sm text-muted-foreground">
                Recommended: Square image, max 5MB
              </p>
            </div>
          </div>
          <Button
            type="submit"
            className="w-full"
            disabled={!serverName.trim() || createServerMutation.isPending}
          >
            Create Server
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}