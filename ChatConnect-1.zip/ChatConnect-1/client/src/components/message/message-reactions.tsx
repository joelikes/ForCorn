import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Smile } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { MessageReaction } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useSelectedChannel } from "@/hooks/use-selected-channel";

const COMMON_EMOJIS = ["👍", "❤️", "😄", "🎉", "🤔", "👀", "🚀", "✨"];

interface MessageReactionsProps {
  messageId: number;
  reactions: MessageReaction[];
}

export function MessageReactions({ messageId, reactions }: MessageReactionsProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { user } = useAuth();
  const { selectedChannelId } = useSelectedChannel();

  const addReactionMutation = useMutation({
    mutationFn: async (emoji: string) => {
      const res = await apiRequest("POST", `/api/messages/${messageId}/reactions`, {
        emoji,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannelId}/messages/reactions`] });
      setIsOpen(false);
    },
  });

  const removeReactionMutation = useMutation({
    mutationFn: async (emoji: string) => {
      await apiRequest("DELETE", `/api/messages/${messageId}/reactions/${emoji}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/channels/${selectedChannelId}/messages/reactions`] });
    },
  });

  // Group reactions by emoji
  const groupedReactions = reactions.reduce((acc, reaction) => {
    if (!acc[reaction.emoji]) {
      acc[reaction.emoji] = [];
    }
    acc[reaction.emoji].push(reaction);
    return acc;
  }, {} as Record<string, MessageReaction[]>);

  return (
    <div className="flex items-center gap-1 mt-1">
      {Object.entries(groupedReactions).map(([emoji, reactions]) => {
        const hasReacted = reactions.some(r => r.userId === user?.id);
        return (
          <Button
            key={emoji}
            variant={hasReacted ? "secondary" : "ghost"}
            size="sm"
            className="h-6 px-2 gap-1"
            onClick={() => {
              if (hasReacted) {
                removeReactionMutation.mutate(emoji);
              } else {
                addReactionMutation.mutate(emoji);
              }
            }}
          >
            <span className="text-base leading-none">{emoji}</span>
            <span className="text-xs leading-none">{reactions.length}</span>
          </Button>
        );
      })}

      <Popover open={isOpen} onOpenChange={setIsOpen}>
        <PopoverTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-6 w-6 p-0 rounded-full hover:bg-accent"
            aria-label="Add reaction"
          >
            <Smile className="h-4 w-4" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full p-2" align="start" side="top">
          <div className="grid grid-cols-4 gap-2">
            {COMMON_EMOJIS.map(emoji => (
              <Button
                key={emoji}
                variant="ghost"
                className="h-8 w-8 p-0 hover:bg-accent"
                onClick={() => {
                  addReactionMutation.mutate(emoji);
                }}
              >
                <span className="text-lg">{emoji}</span>
              </Button>
            ))}
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}