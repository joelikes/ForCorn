import { Avatar, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { User } from "@shared/schema";
import { Activity, UserPlus } from "lucide-react";
import { cn } from "@/lib/utils";

interface ProfileCardProps {
  userId: number;
  isExpanded: boolean;
  onSendFriendRequest?: () => void;
  onViewFullProfile: () => void;
}

const DEFAULT_USER_AVATARS = [
  "https://images.unsplash.com/photo-1630910561339-4e22c7150093",
  "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
  "https://images.unsplash.com/photo-1646617747609-45b466ace9a6",
  "https://images.unsplash.com/photo-1628891435222-065925dcb365",
];

export function ProfileCard({ userId, isExpanded, onSendFriendRequest, onViewFullProfile }: ProfileCardProps) {
  const { data: user } = useQuery<User>({
    queryKey: [`/api/users/${userId}`],
    enabled: !!userId,
  });

  if (!user) return null;

  const avatarUrl = user.avatar || DEFAULT_USER_AVATARS[user.id % DEFAULT_USER_AVATARS.length];

  return (
    <Card className={cn(
      "fixed left-4 transition-all duration-300 ease-in-out p-4 w-64 space-y-4 z-50",
      isExpanded ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2"
    )}>
      <div className="flex items-center gap-3">
        <Avatar className="h-12 w-12">
          <AvatarImage src={avatarUrl} alt={user.username} />
        </Avatar>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold truncate">
            {user.displayName || user.username}
          </h3>
          {user.status && (
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <Activity className="h-3 w-3" />
              {user.status}
            </p>
          )}
        </div>
      </div>

      {user.aboutMe && (
        <p className="text-sm text-muted-foreground line-clamp-2">
          {user.aboutMe}
        </p>
      )}

      <div className="flex gap-2">
        {onSendFriendRequest && (
          <Button
            variant="secondary"
            size="sm"
            className="flex items-center gap-2"
            onClick={onSendFriendRequest}
          >
            <UserPlus className="h-4 w-4" />
            Add Friend
          </Button>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={onViewFullProfile}
        >
          View Profile
        </Button>
      </div>
    </Card>
  );
}
