import { createContext, useContext, ReactNode, useState } from "react";

interface ChannelContextType {
  selectedServerId: number | null;
  selectedChannelId: number | null;
  setSelectedChannel: (serverId: number | null, channelId: number | null) => void;
}

const ChannelContext = createContext<ChannelContextType | null>(null);

export function ChannelProvider({ children }: { children: ReactNode }) {
  const [selectedServerId, setSelectedServerId] = useState<number | null>(null);
  const [selectedChannelId, setSelectedChannelId] = useState<number | null>(null);

  const setSelectedChannel = (serverId: number | null, channelId: number | null) => {
    setSelectedServerId(serverId);
    setSelectedChannelId(channelId);
  };

  return (
    <ChannelContext.Provider
      value={{
        selectedServerId,
        selectedChannelId,
        setSelectedChannel,
      }}
    >
      {children}
    </ChannelContext.Provider>
  );
}

export function useSelectedChannel() {
  const context = useContext(ChannelContext);
  if (!context) {
    throw new Error("useSelectedChannel must be used within a ChannelProvider");
  }
  return context;
}
