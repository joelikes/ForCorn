import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  avatar: text("avatar"),
  aboutMe: text("about_me"),
  displayName: text("display_name"),
  status: text("status").default("offline"),
  customStatus: text("custom_status"),
  profileBackground: text("profile_background"),
  themePreference: text("theme_preference").default("system"),
  customTheme: jsonb("custom_theme").$type<{
    primary: string;
    background: string;
    text: string;
  }>(),
  activityStatus: text("activity_status"),
  badges: text("badges").array(),
  socialConnections: jsonb("social_connections").$type<Record<string, string>>(),
  joinedAt: timestamp("joined_at").notNull().defaultNow(),
});

// Add notifications table after users table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // e.g., 'friend_request'
  title: text("title").notNull(),
  message: text("message").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// New table for server roles
export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  name: text("name").notNull(),
  color: text("color"),
  position: integer("position").notNull(),
  isAdmin: boolean("is_admin").default(false),
  // Permissions stored as a JSON object
  permissions: jsonb("permissions").notNull(),
});

// Table for assigning roles to users in servers
export const userRoles = pgTable("user_roles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  roleId: integer("role_id").notNull(),
  serverId: integer("server_id").notNull(),
});

// Channel permissions override table
export const channelPermissions = pgTable("channel_permissions", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id").notNull(),
  roleId: integer("role_id").notNull(),
  // Permissions stored as a JSON object
  permissions: jsonb("permissions").notNull(),
});

export const friendRequests = pgTable("friend_requests", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected, expired
  message: text("message"), // Optional message field
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  expiresAt: timestamp("expires_at").notNull(), // New field for expiration
});

export const friends = pgTable("friends", {
  id: serial("id").primaryKey(),
  user1Id: integer("user1_id").notNull(),
  user2Id: integer("user2_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  icon: text("icon"),
  ownerId: integer("owner_id").notNull(),
});

// Add new server invites table after the servers table
export const serverInvites = pgTable("server_invites", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  code: text("code").notNull().unique(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serverId: integer("server_id").notNull(),
  isVoice: boolean("is_voice").notNull().default(false),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  channelId: integer("channel_id").notNull(),
  userId: integer("user_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Add new mentions table after the messages table
export const messageMentions = pgTable("message_mentions", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").notNull(),
  userId: integer("user_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

// Add after message mentions table
export const messageReactions = pgTable("message_reactions", {
  id: serial("id").primaryKey(),
  messageId: integer("message_id").notNull(),
  userId: integer("user_id").notNull(),
  emoji: text("emoji").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const directMessages = pgTable("direct_messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  senderId: integer("sender_id").notNull(),
  receiverId: integer("receiver_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const serverMembers = pgTable("server_members", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").notNull(),
  userId: integer("user_id").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
});

// Add system bot table after serverMembers
export const systemBots = pgTable("system_bots", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // e.g., 'notification', 'moderation', etc.
  avatar: text("avatar"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Add bot messages table after directMessages
export const botMessages = pgTable("bot_messages", {
  id: serial("id").primaryKey(),
  botId: integer("bot_id").notNull(),
  userId: integer("user_id").notNull(),
  messageType: text("message_type").notNull(), // e.g., 'friend_request', 'welcome', etc.
  content: text("content").notNull(),
  metadata: jsonb("metadata").$type<Record<string, any>>(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Add new user tags table
export const userTags = pgTable("user_tags", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  serverId: integer("server_id").notNull(),
  tag: text("tag").notNull(),
  color: text("color"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  avatar: true,
  aboutMe: true,
  displayName: true,
  themePreference: true,
  customTheme: true,
  profileBackground: true,
});

// Add after insertUserSchema
export const updateUserProfileSchema = createInsertSchema(users).pick({
  displayName: true,
  aboutMe: true,
}).extend({
  displayName: z.string().nullable(),
  aboutMe: z.string().nullable(),
});

export type UpdateUserProfile = z.infer<typeof updateUserProfileSchema>;

export const insertFriendRequestSchema = createInsertSchema(friendRequests).pick({
  senderId: true,
  receiverId: true,
  message: true,
}).extend({
  message: z.string().optional(),
});

export const insertFriendSchema = createInsertSchema(friends).pick({
  user1Id: true,
  user2Id: true,
});

// Add validation rules to the insertServerSchema
export const insertServerSchema = createInsertSchema(servers).pick({
  name: true,
  icon: true,
  ownerId: true,
}).extend({
  name: z.string()
    .min(1, "Server name is required")
    .max(100, "Server name cannot exceed 100 characters")
    .trim(),
  icon: z.string().optional().nullable(),
  ownerId: z.number()
});

export const insertChannelSchema = createInsertSchema(channels).pick({
  name: true,
  serverId: true,
  isVoice: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  channelId: true,
  userId: true,
});

export const insertDirectMessageSchema = createInsertSchema(directMessages).pick({
  content: true,
  senderId: true,
  receiverId: true,
});

export const insertServerMemberSchema = createInsertSchema(serverMembers).pick({
  serverId: true,
  userId: true,
  isAdmin: true,
});

// Add new insert schemas
export const insertRoleSchema = createInsertSchema(roles).pick({
  serverId: true,
  name: true,
  color: true,
  position: true,
  isAdmin: true,
  permissions: true,
});

export const insertUserRoleSchema = createInsertSchema(userRoles).pick({
  userId: true,
  roleId: true,
  serverId: true,
});

export const insertChannelPermissionSchema = createInsertSchema(channelPermissions).pick({
  channelId: true,
  roleId: true,
  permissions: true,
});

// Add insert schema for server invites
export const insertServerInviteSchema = createInsertSchema(serverInvites).pick({
  serverId: true,
  code: true,
});

// Add the insert schema
export const insertMessageMentionSchema = createInsertSchema(messageMentions).pick({
  messageId: true,
  userId: true,
});

// Add after message mentions insert schema
export const insertMessageReactionSchema = createInsertSchema(messageReactions).pick({
  messageId: true,
  userId: true,
  emoji: true,
});

// Add userTags insert schema
export const insertUserTagSchema = createInsertSchema(userTags).pick({
  userId: true,
  serverId: true,
  tag: true,
  color: true,
});

// Add at the end of the file after other insert schemas
export const insertNotificationSchema = createInsertSchema(notifications).pick({
  userId: true,
  type: true,
  title: true,
  message: true,
});

// Add insert schemas for new tables
export const insertSystemBotSchema = createInsertSchema(systemBots).pick({
  name: true,
  type: true,
  avatar: true,
});

export const insertBotMessageSchema = createInsertSchema(botMessages).pick({
  botId: true,
  userId: true,
  messageType: true,
  content: true,
  metadata: true,
});

// Define permission types
export const PermissionFlags = {
  MANAGE_SERVER: 1 << 0,
  MANAGE_ROLES: 1 << 1,
  MANAGE_CHANNELS: 1 << 2,
  KICK_MEMBERS: 1 << 3,
  BAN_MEMBERS: 1 << 4,
  MANAGE_MESSAGES: 1 << 5,
  SEND_MESSAGES: 1 << 6,
  READ_MESSAGES: 1 << 7,
  ATTACH_FILES: 1 << 8,
  CONNECT_VOICE: 1 << 9,
  SPEAK: 1 << 10,
} as const;

// Select types
export type User = typeof users.$inferSelect;
export type FriendRequest = typeof friendRequests.$inferSelect;
export type Friend = typeof friends.$inferSelect;
export type Server = typeof servers.$inferSelect;
export type Channel = typeof channels.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type DirectMessage = typeof directMessages.$inferSelect;
export type ServerMember = typeof serverMembers.$inferSelect;

// Add new select types
export type Role = typeof roles.$inferSelect;
export type UserRole = typeof userRoles.$inferSelect;
export type ChannelPermission = typeof channelPermissions.$inferSelect;
export type ServerInvite = typeof serverInvites.$inferSelect;
// Add the select type
export type MessageMention = typeof messageMentions.$inferSelect;
// Add after message mentions select type
export type MessageReaction = typeof messageReactions.$inferSelect;

// Add to the existing types section
export type UserTag = typeof userTags.$inferSelect;
// Add at the end of the file after other select types
export type Notification = typeof notifications.$inferSelect;

// Add select types for new tables
export type SystemBot = typeof systemBots.$inferSelect;
export type BotMessage = typeof botMessages.$inferSelect;


// Insert types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertFriendRequest = z.infer<typeof insertFriendRequestSchema>;
export type InsertFriend = z.infer<typeof insertFriendSchema>;
export type InsertServer = z.infer<typeof insertServerSchema>;
export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;
export type InsertServerMember = z.infer<typeof insertServerMemberSchema>;

// Add new insert types
export type InsertRole = z.infer<typeof insertRoleSchema>;
export type InsertUserRole = z.infer<typeof insertUserRoleSchema>;
export type InsertChannelPermission = z.infer<typeof insertChannelPermissionSchema>;
export type InsertServerInvite = z.infer<typeof insertServerInviteSchema>;
export type InsertMessageMention = z.infer<typeof insertMessageMentionSchema>;
// Add after message mentions select type
export type InsertMessageReaction = z.infer<typeof insertMessageReactionSchema>;

// Add to the existing types section
export type InsertUserTag = z.infer<typeof insertUserTagSchema>;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

// Add insert types for new tables
export type InsertSystemBot = z.infer<typeof insertSystemBotSchema>;
export type InsertBotMessage = z.infer<typeof insertBotMessageSchema>;

// Add after the existing types
export type EnrichedFriendRequest = FriendRequest & {
  sender?: User;
};