import { 
  users,
  User,
  Server,
  ServerMember,
  friends,
  Friend,
  serverMembers,
  servers,
  channels,
  messages,
  type Channel,
  type InsertChannel,
  type Message,
  type InsertMessage,
  type InsertServer,
  type InsertServerMember,
  friendRequests,
  type FriendRequest,
  type InsertFriendRequest,
  type InsertUser
} from "@shared/schema";
import { db } from "./db";
import { eq, or, inArray, and, sql, ilike } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import session from "express-session";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(data: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(data)
      .returning();
    return user;
  }

  async searchUsers(query: string): Promise<User[]> {
    if (!query.trim()) {
      return [];
    }

    // Use ilike for case-insensitive search
    const searchPattern = `%${query.trim()}%`;

    const searchResults = await db
      .select()
      .from(users)
      .where(
        or(
          ilike(users.username, searchPattern),
          ilike(users.displayName || '', searchPattern)
        )
      )
      .limit(10);

    console.log('Search query:', query.trim());
    console.log('Search results:', searchResults);

    return searchResults;
  }

  async createFriendRequest(data: InsertFriendRequest & { expiresAt: Date }): Promise<FriendRequest> {
    const [request] = await db
      .insert(friendRequests)
      .values({
        ...data,
        status: 'pending'
      })
      .returning();
    return request;
  }

  async getFriendsForUser(userId: number): Promise<User[]> {
    const friendships = await db
      .select()
      .from(friends)
      .where(
        or(
          eq(friends.user1Id, userId),
          eq(friends.user2Id, userId)
        )
      );

    if (friendships.length === 0) {
      return [];
    }

    const friendIds = friendships.map(f => 
      f.user1Id === userId ? f.user2Id : f.user1Id
    );

    return await db
      .select()
      .from(users)
      .where(inArray(users.id, friendIds));
  }

  // Server-related functions
  async createServer(data: InsertServer): Promise<Server> {
    const [server] = await db.insert(servers).values(data).returning();
    return server;
  }

  async createServerMember(data: InsertServerMember): Promise<ServerMember> {
    const [member] = await db.insert(serverMembers).values(data).returning();
    return member;
  }

  async getServersForUser(userId: number): Promise<Server[]> {
    const memberOf = await db
      .select()
      .from(serverMembers)
      .where(eq(serverMembers.userId, userId));

    if (memberOf.length === 0) {
      return [];
    }

    const serverIds = memberOf.map(m => m.serverId);
    return await db
      .select()
      .from(servers)
      .where(inArray(servers.id, serverIds));
  }

  async getServer(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }

  async getServerMember(serverId: number, userId: number): Promise<ServerMember | undefined> {
    const [member] = await db
      .select()
      .from(serverMembers)
      .where(
        and(
          eq(serverMembers.serverId, serverId),
          eq(serverMembers.userId, userId)
        )
      );
    return member;
  }

  async getMutualServersWithUser(currentUserId: number, otherUserId: number): Promise<Server[]> {
    // Get servers where both users are members
    const membershipMatches = await db
      .select()
      .from(serverMembers)
      .where(
        or(
          eq(serverMembers.userId, currentUserId),
          eq(serverMembers.userId, otherUserId)
        )
      );

    // Group server IDs by user to find mutual servers
    const serversByUser = membershipMatches.reduce((acc, member) => {
      if (!acc[member.userId]) {
        acc[member.userId] = new Set();
      }
      acc[member.userId].add(member.serverId);
      return acc;
    }, {} as Record<number, Set<number>>);

    // Find server IDs that both users are members of
    const currentUserServers = serversByUser[currentUserId] || new Set();
    const otherUserServers = serversByUser[otherUserId] || new Set();
    const mutualServerIds = [...currentUserServers].filter(id => otherUserServers.has(id));

    if (mutualServerIds.length === 0) {
      return [];
    }

    // Fetch the actual server details
    return await db
      .select()
      .from(servers)
      .where(inArray(servers.id, mutualServerIds));
  }

  // Channel-related functions
  async createChannel(data: InsertChannel): Promise<Channel> {
    const [channel] = await db.insert(channels).values(data).returning();
    return channel;
  }

  async getChannel(id: number): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.id, id));
    return channel;
  }

  async getChannelsForServer(serverId: number): Promise<Channel[]> {
    return await db
      .select()
      .from(channels)
      .where(eq(channels.serverId, serverId));
  }

  // Message-related functions
  async createMessage(data: InsertMessage): Promise<Message> {
    const [message] = await db.insert(messages).values(data).returning();
    return message;
  }

  async getMessagesForChannel(channelId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.channelId, channelId))
      .orderBy(sql`${messages.id} DESC`);
  }

  async getFriendRequestsReceived(userId: number): Promise<FriendRequest[]> {
    return await db
      .select()
      .from(friendRequests)
      .where(
        and(
          eq(friendRequests.receiverId, userId),
          eq(friendRequests.status, 'pending')
        )
      );
  }

  async getFriendRequestsSent(userId: number): Promise<FriendRequest[]> {
    return await db
      .select()
      .from(friendRequests)
      .where(
        and(
          eq(friendRequests.senderId, userId),
          eq(friendRequests.status, 'pending')
        )
      );
  }

  async updateFriendRequestStatus(requestId: number, status: 'accepted' | 'rejected'): Promise<void> {
    await db
      .update(friendRequests)
      .set({ status })
      .where(eq(friendRequests.id, requestId));
  }

  async getFriendRequest(id: number): Promise<FriendRequest | undefined> {
    const [request] = await db
      .select()
      .from(friendRequests)
      .where(eq(friendRequests.id, id));
    return request;
  }

  async createFriend(data: {user1Id: number, user2Id: number}): Promise<Friend> { 
    const [friend] = await db
      .insert(friends)
      .values(data)
      .returning();
    return friend;
  }
}

export const storage = new DatabaseStorage();