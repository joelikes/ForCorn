import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertServerSchema, insertChannelSchema, insertMessageSchema } from "@shared/schema";
import express from 'express';
import session from 'express-session';
import { WebSocketServer } from 'ws';
import { setupWebRTC } from "./webrtc";
import { insertFriendRequestSchema } from "@shared/schema";

// Create session middleware
export const sessionMiddleware = session({
  store: storage.sessionStore,
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
  }
});

export function registerRoutes(app: Express): Server {
  // Apply session middleware
  app.use(sessionMiddleware);
  app.use(express.json());

  setupAuth(app);

  // Add server creation route
  app.post('/api/servers', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const serverData = insertServerSchema.parse({
        name: req.body.name,
        icon: req.body.icon,
        ownerId: req.user.id
      });

      const server = await storage.createServer(serverData);

      // Create default member entry for the owner
      await storage.createServerMember({
        serverId: server.id,
        userId: req.user.id,
        isAdmin: true
      });

      console.log('Server created successfully:', server);
      res.json(server);
    } catch (error) {
      console.error('Error creating server:', error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  });

  // Add server list route
  app.get('/api/servers', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const servers = await storage.getServersForUser(req.user.id);
      res.json(servers);
    } catch (error) {
      console.error('Error fetching servers:', error);
      res.status(500).json({ error: 'Failed to fetch servers' });
    }
  });

  // Add server fetch by ID route
  app.get('/api/servers/:id', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const serverId = parseInt(req.params.id);
      const server = await storage.getServer(serverId);

      if (!server) {
        return res.status(404).json({ error: 'Server not found' });
      }

      // Check if user is a member of this server
      const member = await storage.getServerMember(serverId, req.user.id);
      if (!member) {
        return res.status(403).json({ error: 'Access denied' });
      }

      res.json(server);
    } catch (error) {
      console.error('Error fetching server:', error);
      res.status(500).json({ error: 'Failed to fetch server' });
    }
  });

  // Add channel creation route
  app.post('/api/servers/:serverId/channels', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const serverId = parseInt(req.params.serverId);

      // Check if user is a member of this server
      const member = await storage.getServerMember(serverId, req.user.id);
      if (!member) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const channelData = insertChannelSchema.parse({
        name: req.body.name,
        serverId: serverId,
        isVoice: req.body.isVoice || false
      });

      const channel = await storage.createChannel(channelData);
      res.json(channel);
    } catch (error) {
      console.error('Error creating channel:', error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  });

  // Add channels fetch route
  app.get('/api/servers/:serverId/channels', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const serverId = parseInt(req.params.serverId);

      // Check if user is a member of this server
      const member = await storage.getServerMember(serverId, req.user.id);
      if (!member) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const channels = await storage.getChannelsForServer(serverId);
      res.json(channels);
    } catch (error) {
      console.error('Error fetching channels:', error);
      res.status(500).json({ error: 'Failed to fetch channels' });
    }
  });

  // Add message creation route
  app.post('/api/channels/:channelId/messages', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const channelId = parseInt(req.params.channelId);
      const channel = await storage.getChannel(channelId);

      if (!channel) {
        return res.status(404).json({ error: 'Channel not found' });
      }

      // Check if user is a member of this server
      const member = await storage.getServerMember(channel.serverId, req.user.id);
      if (!member) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const messageData = insertMessageSchema.parse({
        content: req.body.content,
        channelId: channelId,
        userId: req.user.id
      });

      const message = await storage.createMessage(messageData);
      res.json(message);
    } catch (error) {
      console.error('Error creating message:', error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: 'Internal server error' });
      }
    }
  });

  // Add messages fetch route
  app.get('/api/channels/:channelId/messages', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const channelId = parseInt(req.params.channelId);
      const channel = await storage.getChannel(channelId);

      if (!channel) {
        return res.status(404).json({ error: 'Channel not found' });
      }

      // Check if user is a member of this server
      const member = await storage.getServerMember(channel.serverId, req.user.id);
      if (!member) {
        return res.status(403).json({ error: 'Access denied' });
      }

      const messages = await storage.getMessagesForChannel(channelId);
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  // Update the search route
  app.get('/api/users/search', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const query = req.query.q as string;

      // Allow empty queries to return an empty array instead of error
      if (!query || typeof query !== 'string') {
        return res.json([]);
      }

      const users = await storage.searchUsers(query);
      // Filter out the current user and remove sensitive data
      const filteredUsers = users
        .filter(user => user.id !== req.user?.id)
        .map(({ password, ...user }) => user);

      console.log('Search query:', query);
      console.log('Search results:', filteredUsers);

      res.json(filteredUsers);
    } catch (error) {
      console.error('Error searching users:', error);
      res.status(500).json({ error: 'Failed to search users' });
    }
  });

  // Add user profile fetch route
  app.get('/api/users/:id', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ error: 'Invalid user ID' });
      }

      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });


  // Add user friends fetch route
  app.get('/api/users/:id/friends', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const userId = parseInt(req.params.id);
      const friends = await storage.getFriendsForUser(userId);
      res.json(friends);
    } catch (error) {
      console.error('Error fetching friends:', error);
      res.status(500).json({ error: 'Failed to fetch friends' });
    }
  });

  // Add mutual servers fetch route
  app.get('/api/users/:id/mutual-servers', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const userId = parseInt(req.params.id);
      const mutualServers = await storage.getMutualServersWithUser(req.user.id, userId);
      res.json(mutualServers);
    } catch (error) {
      console.error('Error fetching mutual servers:', error);
      res.status(500).json({ error: 'Failed to fetch mutual servers' });
    }
  });

  // Add friends list fetch route
  app.get('/api/friends', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const friends = await storage.getFriendsForUser(req.user.id);
      res.json(friends);
    } catch (error) {
      console.error('Error fetching friends:', error);
      res.status(500).json({ error: 'Failed to fetch friends' });
    }
  });

  // Add friend request creation route
  app.post('/api/friend-requests', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const requestData = insertFriendRequestSchema.parse({
        senderId: req.user.id,
        receiverId: req.body.receiverId,
        message: req.body.message,
      });

      // Set expiration to 7 days from now
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 7);

      const friendRequest = await storage.createFriendRequest({
        ...requestData,
        expiresAt,
      });

      res.json(friendRequest);
    } catch (error) {
      console.error('Error creating friend request:', error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: 'Failed to create friend request' });
      }
    }
  });

  // Add friend requests fetch routes
  app.get('/api/friend-requests/received', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const requests = await storage.getFriendRequestsReceived(req.user.id);
      res.json(requests);
    } catch (error) {
      console.error('Error fetching received friend requests:', error);
      res.status(500).json({ error: 'Failed to fetch friend requests' });
    }
  });

  app.get('/api/friend-requests/sent', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const requests = await storage.getFriendRequestsSent(req.user.id);
      res.json(requests);
    } catch (error) {
      console.error('Error fetching sent friend requests:', error);
      res.status(500).json({ error: 'Failed to fetch friend requests' });
    }
  });

  // Add friend request response route
  app.post('/api/friend-requests/:id/respond', async (req, res) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    try {
      const requestId = parseInt(req.params.id);
      const { action } = req.body;

      if (!action || !['accept', 'reject'].includes(action)) {
        return res.status(400).json({ error: 'Invalid action' });
      }

      // Update the friend request status
      await storage.updateFriendRequestStatus(requestId, action === 'accept' ? 'accepted' : 'rejected');

      // If accepted, create friend relationship
      if (action === 'accept') {
        const request = await storage.getFriendRequest(requestId);
        if (!request) {
          return res.status(404).json({ error: 'Friend request not found' });
        }

        await storage.createFriend({
          user1Id: request.senderId,
          user2Id: request.receiverId,
        });
      }

      res.json({ success: true });
    } catch (error) {
      console.error('Error responding to friend request:', error);
      if (error instanceof Error) {
        res.status(400).json({ error: error.message });
      } else {
        res.status(500).json({ error: 'Failed to respond to friend request' });
      }
    }
  });

  const httpServer = createServer(app);

  // Setup WebRTC signaling with session middleware
  setupWebRTC(httpServer, sessionMiddleware);

  // Create WebSocket server for real-time notifications
  const wss = new WebSocketServer({
    noServer: true,
    path: '/ws'
  });

  // Handle WebSocket upgrade
  httpServer.on('upgrade', (request: any, socket, head) => {
    if (request.url === '/ws') {
      sessionMiddleware(request, {} as express.Response, () => {
        if (!request.session?.passport?.user) {
          socket.destroy();
          return;
        }

        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      });
    }
  });

  // Add error handling middleware
  app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Server error:', err);
    res.status(500).json({ error: err.message });
  });

  return httpServer;
}