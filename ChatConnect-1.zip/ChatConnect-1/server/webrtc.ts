import { WebSocketServer, WebSocket } from 'ws';
import { Server } from "http";
import type { RequestHandler } from 'express';
import type { IncomingMessage } from 'http';
import { storage } from './storage';

interface SignalingMessage {
  type: "offer" | "answer" | "ice-candidate" | "call_request" | "call_accepted" | "call_rejected";
  from?: number | { id: number; username: string; displayName: string };
  to: number;
  data?: any;
}

declare module 'http' {
  interface IncomingMessage {
    session?: {
      passport?: {
        user?: number;
      };
    };
  }
}

const clients = new Map<number, WebSocket>();

export function setupWebRTC(server: Server, sessionMiddleware: RequestHandler) {
  const wss = new WebSocketServer({
    noServer: true,
    path: '/webrtc'
  });

  server.on('upgrade', (request: IncomingMessage, socket, head) => {
    if (request.url === '/webrtc') {
      sessionMiddleware(request as any, {} as any, () => {
        if (!request.session?.passport?.user) {
          socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
          socket.destroy();
          return;
        }

        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      });
    }
  });

  wss.on('connection', async (ws: WebSocket & { isAlive?: boolean }, request: IncomingMessage) => {
    const userId = request.session?.passport?.user;
    if (!userId) {
      ws.send(JSON.stringify({ type: 'error', message: 'Authentication required' }));
      ws.close();
      return;
    }

    clients.set(userId, ws);
    ws.isAlive = true;

    console.log(`WebRTC client connected for user: ${userId}`);

    ws.on('pong', () => {
      ws.isAlive = true;
    });

    ws.on('message', async (message: string) => {
      try {
        const data: SignalingMessage = JSON.parse(message.toString());
        const recipientWs = clients.get(data.to);

        if (recipientWs && recipientWs.readyState === WebSocket.OPEN) {
          // For call requests, include user information
          if (data.type === 'call_request') {
            const caller = await storage.getUser(userId);
            if (caller) {
              recipientWs.send(JSON.stringify({
                ...data,
                from: {
                  id: caller.id,
                  username: caller.username,
                  displayName: caller.displayName
                }
              }));
            }
          } else {
            recipientWs.send(JSON.stringify({
              ...data,
              from: userId
            }));
          }
        } else {
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Recipient is not available'
          }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({
          type: 'error',
          message: 'Invalid message format'
        }));
      }
    });

    ws.on('close', () => {
      clients.delete(userId);
      console.log(`WebRTC client disconnected for user: ${userId}`);
    });
  });

  // Keep-alive ping
  const interval = setInterval(() => {
    wss.clients.forEach((ws: WebSocket & { isAlive?: boolean }) => {
      if (ws.isAlive === false) {
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });
}