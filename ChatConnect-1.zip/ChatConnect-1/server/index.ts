import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { WebSocketServer, type WebSocket as WSType } from 'ws';
import { createServer } from 'http';
import { backupService } from './services/backup-service';
import { IncomingMessage } from 'http';

const app = express();
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: false, limit: '10mb' }));

// Logging middleware
app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Initialize backup service first
  try {
    await backupService.initialize();
    log('Backup service initialized successfully');

    // Schedule periodic backups (every 24 hours)
    setInterval(async () => {
      try {
        const backupPath = await backupService.createBackup();
        log(`Scheduled backup created successfully at ${backupPath}`);
      } catch (error) {
        console.error('Scheduled backup failed:', error);
      }
    }, 24 * 60 * 60 * 1000); // 24 hours
  } catch (error) {
    console.error('Failed to initialize backup service:', error);
  }

  const httpServer = createServer(app);

  // First register routes and auth
  const server = await registerRoutes(app);

  // Then set up WebSocket server
  const wss = new WebSocketServer({ 
    noServer: true,
    path: '/ws'  // Explicit path to avoid conflicts
  });

  // Store connected clients with their user IDs
  const clients: Map<number, WSType> = new Map();

  // Handle upgrade requests explicitly
  httpServer.on('upgrade', (request: IncomingMessage, socket, head) => {
    const path = request.url || '';

    // Only handle /ws endpoint, let other handlers manage their paths
    if (path === '/ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  wss.on('connection', (ws: WSType) => {
    log('WebSocket client connected');

    ws.on('message', (rawData: Buffer) => {
      try {
        const data = rawData.toString();
        const message = JSON.parse(data);

        if (message.type === 'identify') {
          clients.set(message.userId, ws);
          log(`User ${message.userId} identified via WebSocket`);
        } else if (message.type === 'friendRequest') {
          const recipientWs = clients.get(message.recipientId);
          if (recipientWs?.readyState === WebSocket.OPEN) {
            recipientWs.send(JSON.stringify({
              type: 'friend_request',
              title: 'New Friend Request',
              message: `@${message.sender.username} sent you a friend request`,
              data: {
                requestId: message.requestId,
                sender: {
                  id: message.sender.id,
                  username: message.sender.username,
                  displayName: message.sender.displayName
                }
              }
            }));
            log(`Sent friend request notification to user ${message.recipientId}`);
          } else {
            log(`Recipient ${message.recipientId} not connected or socket not ready`);
          }
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
        log(`WebSocket message parse error: ${error}`);
      }
    });

    ws.on('close', () => {
      clients.forEach((client, userId) => {
        if (client === ws) {
          clients.delete(userId);
          log(`User ${userId} disconnected from WebSocket`);
        }
      });
    });

    ws.on('error', (error) => {
      log(`WebSocket error: ${error.message}`);
    });
  });

  // Make WebSocket server available to routes
  app.set('wss', wss);
  app.set('wsClients', clients);

  // Error handling middleware
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    console.error('Server error:', err);
    res.status(status).json({ message });
  });

  // Set up Vite or static serving last
  if (app.get("env") === "development") {
    await setupVite(app, httpServer);
  } else {
    serveStatic(app);
  }

  const PORT = 5000;
  httpServer.listen(PORT, "0.0.0.0", () => {
    log(`Server running on port ${PORT}`);
  });
})();