import { performance } from 'perf_hooks';
import { db } from '../db';
import { WebSocket } from 'ws';
import os from 'os';

interface SystemMetrics {
  cpuUsage: number;
  memoryUsage: {
    total: number;
    used: number;
    free: number;
  };
  uptime: number;
}

interface ConnectionMetrics {
  activeWebSocketConnections: number;
  webRTCConnections: number;
}

interface DatabaseMetrics {
  status: 'healthy' | 'error';
  responseTime: number;
  lastChecked: Date;
}

interface APIMetrics {
  endpoint: string;
  responseTime: number;
  status: number;
  timestamp: Date;
}

export class MonitoringService {
  private static instance: MonitoringService;
  private apiMetrics: APIMetrics[] = [];
  private lastDatabaseCheck: DatabaseMetrics = {
    status: 'healthy',
    responseTime: 0,
    lastChecked: new Date()
  };

  private constructor() {}

  static getInstance(): MonitoringService {
    if (!MonitoringService.instance) {
      MonitoringService.instance = new MonitoringService();
    }
    return MonitoringService.instance;
  }

  async getSystemMetrics(): Promise<SystemMetrics> {
    const cpus = os.cpus();
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();

    return {
      cpuUsage: this.calculateCPUUsage(cpus),
      memoryUsage: {
        total: totalMemory,
        used: totalMemory - freeMemory,
        free: freeMemory
      },
      uptime: os.uptime()
    };
  }

  private calculateCPUUsage(cpus: os.CpuInfo[]): number {
    const usage = cpus.reduce((acc, cpu) => {
      const total = Object.values(cpu.times).reduce((a, b) => a + b);
      const idle = cpu.times.idle;
      return acc + ((total - idle) / total);
    }, 0);
    
    return (usage / cpus.length) * 100;
  }

  getConnectionMetrics(wsServer: any, webRTCServer: any): ConnectionMetrics {
    return {
      activeWebSocketConnections: Array.from(wsServer.clients).filter(
        (client: WebSocket) => client.readyState === WebSocket.OPEN
      ).length,
      webRTCConnections: Array.from(webRTCServer.clients).filter(
        (client: WebSocket) => client.readyState === WebSocket.OPEN
      ).length
    };
  }

  async checkDatabaseHealth(): Promise<DatabaseMetrics> {
    const start = performance.now();
    try {
      await db.query(sql`SELECT 1`);
      this.lastDatabaseCheck = {
        status: 'healthy',
        responseTime: performance.now() - start,
        lastChecked: new Date()
      };
    } catch (error) {
      this.lastDatabaseCheck = {
        status: 'error',
        responseTime: performance.now() - start,
        lastChecked: new Date()
      };
    }
    return this.lastDatabaseCheck;
  }

  recordAPIMetric(endpoint: string, responseTime: number, status: number): void {
    this.apiMetrics.push({
      endpoint,
      responseTime,
      status,
      timestamp: new Date()
    });

    // Keep only the last 1000 metrics
    if (this.apiMetrics.length > 1000) {
      this.apiMetrics = this.apiMetrics.slice(-1000);
    }
  }

  getAPIMetrics(): APIMetrics[] {
    return this.apiMetrics;
  }

  async getAllMetrics(wsServer: any, webRTCServer: any) {
    const [systemMetrics, databaseMetrics] = await Promise.all([
      this.getSystemMetrics(),
      this.checkDatabaseHealth()
    ]);

    return {
      system: systemMetrics,
      connections: this.getConnectionMetrics(wsServer, webRTCServer),
      database: databaseMetrics,
      api: this.getAPIMetrics()
    };
  }
}

export const monitoringService = MonitoringService.getInstance();
