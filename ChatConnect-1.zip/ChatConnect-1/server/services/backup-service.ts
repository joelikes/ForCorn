import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'fs/promises';
import path from 'path';
import { format } from 'date-fns';

const execAsync = promisify(exec);

export class BackupService {
  private backupDir: string;
  private maxBackups: number;

  constructor(backupDir = 'backups', maxBackups = 7) {
    this.backupDir = backupDir;
    this.maxBackups = maxBackups;
  }

  async initialize() {
    try {
      await fs.mkdir(this.backupDir, { recursive: true });
      console.log(`Backup directory created at ${this.backupDir}`);
    } catch (error) {
      console.error('Error creating backup directory:', error);
      throw error;
    }
  }

  async createBackup(): Promise<string> {
    const timestamp = format(new Date(), 'yyyy-MM-dd-HH-mm-ss');
    const filename = `backup-${timestamp}.sql`;
    const filepath = path.join(this.backupDir, filename);

    try {
      const { PGDATABASE, PGUSER, PGPASSWORD, PGHOST, PGPORT } = process.env;
      
      const command = [
        'pg_dump',
        `-d postgresql://${PGUSER}:${PGPASSWORD}@${PGHOST}:${PGPORT}/${PGDATABASE}`,
        '-F p', // plain text format
        `-f ${filepath}`,
      ].join(' ');

      await execAsync(command);
      console.log(`Backup created successfully: ${filename}`);

      // Cleanup old backups
      await this.cleanupOldBackups();

      return filepath;
    } catch (error) {
      console.error('Error creating backup:', error);
      throw error;
    }
  }

  private async cleanupOldBackups() {
    try {
      const files = await fs.readdir(this.backupDir);
      const backupFiles = files
        .filter(file => file.startsWith('backup-') && file.endsWith('.sql'))
        .sort()
        .reverse();

      if (backupFiles.length > this.maxBackups) {
        const filesToDelete = backupFiles.slice(this.maxBackups);
        await Promise.all(
          filesToDelete.map(file =>
            fs.unlink(path.join(this.backupDir, file))
          )
        );
        console.log(`Cleaned up ${filesToDelete.length} old backup(s)`);
      }
    } catch (error) {
      console.error('Error cleaning up old backups:', error);
    }
  }

  async listBackups(): Promise<string[]> {
    try {
      const files = await fs.readdir(this.backupDir);
      return files
        .filter(file => file.startsWith('backup-') && file.endsWith('.sql'))
        .sort()
        .reverse();
    } catch (error) {
      console.error('Error listing backups:', error);
      return [];
    }
  }
}

export const backupService = new BackupService();
