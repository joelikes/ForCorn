import { storage } from "../storage";
import type { User, SystemBot, FriendRequest } from "@shared/schema";

class NotificationBot {
  private bot: SystemBot | null = null;

  async initialize() {
    // Get or create the notification bot
    let bot = await storage.getSystemBotByType("notification");

    if (!bot) {
      bot = await storage.createSystemBot({
        name: "NotifyBot",
        type: "notification",
        avatar: "🤖", // Using an emoji as avatar
      });
    }

    this.bot = bot;
  }

  async sendFriendRequestNotification(
    request: FriendRequest,
    sender: User,
    receiver: User
  ) {
    if (!this.bot) {
      await this.initialize();
    }

    const content = `👋 Hey ${receiver.displayName || receiver.username}!

@${sender.displayName || sender.username} sent you a friend request${request.message ? `: "${request.message}"` : "!"}.

To respond to this request, click the friend requests icon (🤝) in the server sidebar. There you can accept or reject the request.

Best,
NotifyBot 🤖`;

    await storage.createBotMessage({
      botId: this.bot!.id,
      userId: receiver.id,
      messageType: "friend_request",
      content,
      metadata: {
        requestId: request.id,
        senderId: sender.id,
        receiverId: receiver.id,
        timestamp: new Date().toISOString()
      },
    });
  }
}

export const notificationBot = new NotificationBot();